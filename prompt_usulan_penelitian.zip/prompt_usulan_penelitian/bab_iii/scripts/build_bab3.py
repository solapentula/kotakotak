#!/usr/bin/env python3
"""
build_bab3.py — Render BAB III KERANGKA BERPIKIR, KONSEP PENELITIAN DAN
HIPOTESIS PENELITIAN (usulan penelitian) ke .docx sesuai Panduan Penulisan
Pascasarjana Universitas Udayana 2024.

Pemakaian:
    python scripts/build_bab3.py <input.json> <output.docx>

Selain .docx, skrip menulis berkas mermaid (.mmd) bersebelahan dengan .docx
(nama dasar sama) berisi kode bagan 3.2 agar dapat dirender terpisah.

Format yang ditegakkan otomatis (identik dengan build_bab1/2):
- Kertas A4, margin kiri 4 cm / atas-bawah-kanan 3 cm
- Times New Roman 12 pt, spasi 1,5 (isi); daftar/caption 1 spasi
- Heading "BAB III" + judul bab kapital, tebal, simetris
- Subbab (3.1 dst.) rata kiri, tebal
- Paragraf isi rata kanan-kiri (justify), indentasi baris pertama ~1,27 cm
- Istilah yang ditandai *miring* dirender italic
- Hipotesis sebagai daftar BERNOMOR (bukan bullet/dash)
- 3.2 Konsep: kode mermaid dirender dalam kotak monospace + caption "Bagan 3.1"
  DI BAWAH (kaidah caption gambar/bagan UNUD), serta ditulis ke berkas .mmd

Skema JSON (ringkas):
{
  "judul": "JUDUL STUDI (konteks; tidak dicetak sebagai heading)",
  "bab_nomor": "III",                                   # opsional
  "bab_judul": "KERANGKA BERPIKIR, KONSEP PENELITIAN DAN HIPOTESIS PENELITIAN",
  "kerangka_berpikir": ["paragraf 1", "...", "paragraf 4"],   # tanpa sitasi
  "konsep_uraian": ["uraian kualitatif singkat ...", "..."],  # opsional
  "konsep_bagan": {
    "nomor": "3.1",
    "caption": "Konsep Penelitian",
    "mermaid": "flowchart TD\n  ...",
    "sumber": ""                                          # opsional
  },
  "hipotesis_pengantar": "Berdasarkan kerangka berpikir di atas, ...",  # opsional
  "hipotesis": ["Terdapat perbedaan ...", "..."],
  "referensi": []                                         # opsional, biasanya kosong
}
Markup *miring* berlaku di paragraf, uraian, dan hipotesis.
"""

import sys
import json
import re
import os

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Times New Roman"
MONO = "Courier New"
SIZE = 12
INDENT = Cm(1.27)
LIST_INDENT = Cm(0.9)


# ---------- util italic markup ----------
def add_runs(paragraph, text, *, italic_all=False, bold_all=False, size=SIZE, font=FONT):
    if text is None:
        text = ""
    parts = re.split(r"(\*[^*]+\*)", str(text))
    for part in parts:
        if part == "":
            continue
        if len(part) >= 2 and part.startswith("*") and part.endswith("*"):
            run = paragraph.add_run(part[1:-1])
            run.italic = True
        else:
            run = paragraph.add_run(part)
            run.italic = italic_all
        if bold_all:
            run.bold = True
        run.font.name = font
        run.font.size = Pt(size)
        _set_run_font(run, font)
    return paragraph


def _set_run_font(run, font_name):
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(attr), font_name)


# ---------- paragraf helpers ----------
def body_paragraph(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.first_line_indent = INDENT
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


def plain_paragraph(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


def numbered_item(doc, n, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.left_indent = LIST_INDENT + Cm(0.7)
    pf.first_line_indent = -Cm(0.7)
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    lead = p.add_run(f"{n}.\t")
    lead.font.name = FONT
    lead.font.size = Pt(SIZE)
    _set_run_font(lead, FONT)
    add_runs(p, text)
    return p


def subbab(doc, nomor, judul, space_before=12):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_before = Pt(space_before)
    pf.space_after = Pt(0)
    add_runs(p, f"{nomor}\t{judul}" if nomor else judul, bold_all=True)
    return p


def chapter_heading(doc, line1, line2):
    for i, line in enumerate((line1, line2)):
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
        pf.line_spacing = 1.5
        pf.space_before = Pt(28) if i == 0 else Pt(0)
        pf.space_after = Pt(18) if i == 1 else Pt(0)
        run = p.add_run(line.upper())
        run.bold = True
        run.font.name = FONT
        run.font.size = Pt(SIZE)
        _set_run_font(run, FONT)


def reference_entry(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    pf.left_indent = Cm(1.27)
    pf.first_line_indent = -Cm(1.27)
    pf.space_after = Pt(6)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


# ---------- BAGAN 3.2: kotak kode mermaid + caption di bawah ----------
def _single_box_border(cell, sz=6):
    tcPr = cell._tc.get_or_add_tcPr()
    old = tcPr.find(qn("w:tcBorders"))
    if old is not None:
        tcPr.remove(old)
    borders = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), "000000")
        borders.append(el)
    tcPr.append(borders)


def render_bagan_mermaid(doc, bagan):
    """Render kode mermaid dalam kotak monospace + caption 'Bagan X' di bawah."""
    nomor = bagan.get("nomor", "3.1")
    caption = bagan.get("caption", "Konsep Penelitian")
    code = (bagan.get("mermaid") or "").rstrip("\n")
    sumber = bagan.get("sumber", "")

    # Catatan instruksi (italic, kecil)
    note = doc.add_paragraph()
    nf = note.paragraph_format
    nf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    nf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    nf.space_before = Pt(8)
    nf.space_after = Pt(4)
    nrun = note.add_run(
        "[Bagan dibuat dari kode mermaid berikut. Render kode ini (mis. di "
        "mermaid.live atau penampil mermaid) lalu sisipkan hasilnya sebagai "
        f"Bagan {nomor}; kode yang sama tersedia pada berkas .mmd.]"
    )
    nrun.italic = True
    nrun.font.name = FONT
    nrun.font.size = Pt(10)
    _set_run_font(nrun, FONT)

    # Kotak kode (1x1 table) berisi kode mermaid monospace
    if code:
        table = doc.add_table(rows=1, cols=1)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        cell = table.rows[0].cells[0]
        _single_box_border(cell)
        cell.text = ""
        first = True
        for line in code.split("\n"):
            p = cell.paragraphs[0] if first else cell.add_paragraph()
            first = False
            pf = p.paragraph_format
            pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
            pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
            pf.space_before = Pt(0)
            pf.space_after = Pt(0)
            # tabulasi mermaid -> spasi agar rapi
            run = p.add_run(line if line else " ")
            run.font.name = MONO
            run.font.size = Pt(9)
            _set_run_font(run, MONO)

    # Caption DI BAWAH (kaidah gambar/bagan UNUD), simetris, spasi 1
    cap = doc.add_paragraph()
    cf = cap.paragraph_format
    cf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    cf.space_before = Pt(6)
    cf.space_after = Pt(8)
    teks = f"Bagan {nomor}. {caption}"
    if sumber:
        teks = teks.rstrip() + f" ({sumber})"
    add_runs(cap, teks)


# ---------- page setup & footer ----------
def setup_page(doc):
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.left_margin = Cm(4.0)
    sec.right_margin = Cm(3.0)
    sec.top_margin = Cm(3.0)
    sec.bottom_margin = Cm(3.0)

    style = doc.styles["Normal"]
    style.font.name = FONT
    style.font.size = Pt(SIZE)
    style.font.color.rgb = RGBColor(0, 0, 0)
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(attr), FONT)


def add_centered_page_number(doc):
    footer = doc.sections[0].footer
    footer.is_linked_to_previous = False
    p = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    fld_begin = OxmlElement("w:fldChar"); fld_begin.set(qn("w:fldCharType"), "begin")
    instr_el = OxmlElement("w:instrText"); instr_el.set(qn("xml:space"), "preserve"); instr_el.text = "PAGE"
    fld_end = OxmlElement("w:fldChar"); fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin); run._r.append(instr_el); run._r.append(fld_end)
    run.font.name = FONT; run.font.size = Pt(SIZE); _set_run_font(run, FONT)


# ---------- validasi ringan ----------
CIT_PATTERN = re.compile(r"\([A-Za-zÀ-ÿ.'’\- ]+,\s*\d{4}[a-z]?\)|\b[A-Z][A-Za-zÀ-ÿ'’\-]+ et al\.,?\s*\(?\d{4}")


def validate(data):
    warn = sys.stderr.write
    kb = data.get("kerangka_berpikir", []) or []
    if not kb:
        warn("PERINGATAN: 'kerangka_berpikir' kosong.\n")
    elif len(kb) != 4:
        warn(f"CATATAN: 'kerangka_berpikir' berisi {len(kb)} paragraf; cetak biru "
             "menyarankan 4 paragraf (deduktif + induktif).\n")
    # 3.1 TIDAK boleh mengandung sitasi
    for i, para in enumerate(kb, 1):
        if CIT_PATTERN.search(para or ""):
            warn(f"PERINGATAN: paragraf kerangka berpikir #{i} tampak mengandung "
                 "sitasi (X, tahun). Subbab 3.1 harus tanpa sitasi.\n")

    bagan = data.get("konsep_bagan") or {}
    if not bagan.get("mermaid"):
        warn("PERINGATAN: 'konsep_bagan.mermaid' kosong; 3.2 memerlukan bagan.\n")

    hyp = data.get("hipotesis", []) or []
    if not hyp:
        warn("PERINGATAN: 'hipotesis' kosong.\n")
    for i, h in enumerate(hyp, 1):
        if h.strip().endswith("?"):
            warn(f"PERINGATAN: hipotesis #{i} berbentuk pertanyaan; hipotesis harus "
                 "kalimat POSITIF (mis. 'Terdapat perbedaan ...').\n")


# ---------- main ----------
def build(data, out_path):
    validate(data)

    doc = Document()
    setup_page(doc)
    add_centered_page_number(doc)

    bab_nomor = data.get("bab_nomor", "III")
    bab_judul = data.get(
        "bab_judul",
        "KERANGKA BERPIKIR, KONSEP PENELITIAN DAN HIPOTESIS PENELITIAN",
    )
    chapter_heading(doc, f"BAB {bab_nomor}", bab_judul)

    # 3.1 Kerangka Berpikir
    subbab(doc, f"{bab_nomor_to_num(bab_nomor)}.1", "Kerangka Berpikir", space_before=0)
    for para in data.get("kerangka_berpikir", []) or []:
        body_paragraph(doc, para)

    # 3.2 Konsep Penelitian
    subbab(doc, f"{bab_nomor_to_num(bab_nomor)}.2", "Konsep Penelitian")
    for para in data.get("konsep_uraian", []) or []:
        body_paragraph(doc, para)
    bagan = data.get("konsep_bagan")
    if bagan:
        render_bagan_mermaid(doc, bagan)

    # 3.3 Hipotesis
    subbab(doc, f"{bab_nomor_to_num(bab_nomor)}.3", "Hipotesis")
    pengantar = data.get("hipotesis_pengantar")
    if pengantar:
        plain_paragraph(doc, pengantar)
    for i, h in enumerate(data.get("hipotesis", []) or [], 1):
        numbered_item(doc, i, h)

    # Referensi (opsional; biasanya kosong untuk BAB III)
    refs = data.get("referensi", []) or []
    if refs:
        subbab(doc, "", "Daftar Referensi (BAB III)")
        note = plain_paragraph(
            doc,
            "Daftar kerja sumber (APA 7) untuk memudahkan penyusunan Daftar "
            "Pustaka akhir; bukan bagian formal bab.",
        )
        for r in note.runs:
            r.italic = True
        for entry in sorted(refs, key=lambda s: s.lower()):
            reference_entry(doc, entry)

    doc.save(out_path)

    # Tulis berkas .mmd bersebelahan
    mmd_path = os.path.splitext(out_path)[0] + ".mmd"
    code = ((data.get("konsep_bagan") or {}).get("mermaid") or "").rstrip("\n")
    if code:
        with open(mmd_path, "w", encoding="utf-8") as f:
            f.write(code + "\n")

    print(f"Tersimpan: {out_path}")
    if code:
        print(f"Kode mermaid: {mmd_path}")
    print(f"Jumlah paragraf Kerangka Berpikir: {len(data.get('kerangka_berpikir', []) or [])}")
    print(f"Jumlah hipotesis: {len(data.get('hipotesis', []) or [])}")
    print(f"Jumlah referensi: {len(refs)}")


def bab_nomor_to_num(bab_nomor):
    """Ubah angka romawi bab (III) -> '3' untuk penomoran subbab."""
    roman = {"I": 1, "II": 2, "III": 3, "IV": 4, "V": 5, "VI": 6}
    return str(roman.get(str(bab_nomor).strip().upper(), bab_nomor))


def main():
    if len(sys.argv) != 3:
        sys.stderr.write("Pemakaian: python build_bab3.py <input.json> <output.docx>\n")
        sys.exit(1)
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    build(data, sys.argv[2])


if __name__ == "__main__":
    main()
