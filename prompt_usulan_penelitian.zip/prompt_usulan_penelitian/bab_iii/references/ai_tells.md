# Tanda-tanda tulisan AI — dan cara menghindarinya (BAB III)

Acuan ringkas untuk memastikan Kerangka Berpikir, Konsep, dan Hipotesis **tidak terbaca seperti keluaran model bahasa**. Disarikan dan diadaptasi dari esai *Wikipedia: Signs of AI writing* ke konteks usulan penelitian anestesi/ICU berbahasa Indonesia. **Baca sekali sebelum menulis**, lalu pakai checklist di akhir sebagai uji-mandiri sebelum render. Pada BAB III taruhannya khas: 3.1 harus terbaca sebagai **penalaran orisinal peneliti yang koheren dengan BAB I–II**, **tanpa sitasi** — bukan parafrase berputar dari BAB II.

> **Peringatan penting (jangan jadi pemburu kata kunci).** Tidak ada satu kata pun yang otomatis "haram". Tujuannya **bukan** menghapus daftar kata, melainkan menulis penalaran yang **logis, spesifik, dan koheren** sehingga tanda-tanda ini hilang sendiri. Satu-dua frasa di bawah bisa muncul wajar; yang menjadi tanda AI adalah **kepadatannya** dalam satu paragraf.

---

## A. Tanda khas BAB III

**A0. Sitasi yang terselip di 3.1.** Kerangka berpikir adalah **sintesis penalaran**, bukan kajian pustaka. Bila muncul `(Penulis, Tahun)` atau "studi menunjukkan", materinya seharusnya di BAB I/II. Pindahkan, jangan paksakan di sini.
- Buruk: "Beberapa studi (Forero et al., 2016; Costache et al., 2017) menunjukkan kedua blok efektif."
- Baik: "Kedua teknik menunjukkan efektivitas pada konteksnya masing-masing, tetapi pola yang terserak ini belum cukup untuk menyimpulkan keunggulan relatif."

**A1. Parafrase BAB II, bukan penalaran.** Kerangka berpikir yang hanya meringkas ulang tinjauan pustaka = generik. Tiap paragraf harus melakukan **satu kerja logis**: premis teoretis → prediksi terarah → keterbatasan bukti → rasionale.

**A2. Penekanan berlebihan pada signifikansi.** "Sangat penting", "memegang peranan krusial", "menjadi tonggak" tanpa logika. Ganti dengan penanda penalaran: "secara logis akan", "secara teoritis diprediksi", "belum cukup untuk menyimpulkan".

**A3. Hipotesis yang tidak mencerminkan rumusan masalah.** Jumlah/isi hipotesis harus **persis** mencerminkan rumusan masalah BAB I dan luaran BAB II. Hipotesis berbentuk pertanyaan, atau jumlah yang tidak cocok, adalah tanda kerja yang tidak koheren.

**A4. Penutup formulaik "tantangan & prospek masa depan".** Hindari "Meski demikian, masih banyak tantangan ... ke depannya diharapkan ...". Paragraf rasionale menutup dengan arah penelitian yang konkret.

---

## B. Tanda pada BAHASA & TATA KALIMAT

**B1. Densitas tinggi "kosakata-AI".** Padanan Indonesia yang patut diwaspadai (pakai hemat, jangan menumpuk):

> *lanskap* (metafora), *menggarisbawahi*, *menyoroti*, *menjadi bukti / testament*, *tak terbantahkan / tidak dapat dipungkiri*, *memainkan peran (penting/krusial/vital/pivotal)*, *secara signifikan* (di luar makna statistik), *komprehensif*, *holistik*, *mendalam*, *rumit/kompleks nan*, *beragam / berbagai macam*, *di era modern ini*, *seiring perkembangan zaman*, *di tengah*, *pada akhirnya*, *yang patut dicatat*, *menjembatani kesenjangan*, *membuka jalan bagi*, *mengoptimalkan*, *tonggak / babak baru*.

**B2. Paralelisme negatif.** "**bukan hanya … tetapi juga …**" / "**bukan … melainkan …**" sebagai bumbu retoris. Berulang = tanda AI. Catatan: "bukan satu, melainkan seluruh jalur" boleh bila memang bermakna logis (menegaskan cakupan), bukan hiasan.

**B3. Pola tiga-serangkai (*rule of three*).** Daftar tiga sifat yang dipaksakan ("aman, efektif, dan ekonomis"). Catatan: penyebutan tiga komponen nyata (somatik, viseral, simpatetik) sah karena merujuk entitas faktual, bukan hiasan.

**B4. Variasi elegan (*elegant variation*).** Mengganti-ganti sebutan untuk istilah yang harus **konsisten** dengan BAB I–II (tetap "blok MTP", "TPVS", "*time to first rescue analgesia*"). Konsistensi istilah menjaga benang merah antar-bab.

**B5. Over-nominalisasi.** Pilih kata kerja langsung; pasif baku tetap boleh.

---

## C. Tanda pada GAYA, TRANSISI & MARKUP

**C1. Penjejalan transisi.** "Selain itu", "Lebih lanjut", "Selanjutnya" di tiap awal kalimat. Pakai hanya saat ada sebab-akibat/pertentangan nyata.

**C2. Editorializing / hedging klise.** "Penting untuk dicatat bahwa", "patut digarisbawahi", "menariknya". Hapus; sampaikan penalarannya.

**C3. Ritme kalimat seragam.** Selang-seling kalimat kompleks dengan kalimat pendek yang tegas.

**C4. Markup & bagan.** Jangan menaruh **boldface**, *Title Case*, em dash (—) dekoratif, kutip melengkung, atau emoji di teks JSON. Miring hanya untuk istilah asing via `*asterisk*`. **Bagan harus hitam-putih** (tanpa warna); garis penuh = diteliti, putus-putus = tidak diteliti. Penomoran hipotesis & caption bagan ditangani skrip.

---

## Checklist uji-mandiri (jalankan sebelum render)

1. Kerangka berpikir tepat **4 paragraf** dengan alur deduktif + induktif (premis → prediksi → keterbatasan → rasionale)?
2. **Tidak ada sitasi** `(Penulis, Tahun)` di seluruh 3.1?
3. Tiap paragraf melakukan satu kerja logis (bukan parafrase ulang BAB II)?
4. Penanda penalaran eksplisit ("secara logis", "secara teoritis diprediksi", "belum cukup menyimpulkan") menggantikan penekanan kosong?
5. Istilah konsisten dengan BAB I–II (tanpa variasi sinonim)?
6. Tidak ada frasa B1 yang menumpuk, paralelisme negatif hiasan, atau tiga-serangkai dipaksakan?
7. Tidak ada "penting untuk dicatat / tidak dapat dipungkiri / seiring perkembangan zaman"?
8. Tidak ada penutup "tantangan & prospek masa depan" yang formulaik?
9. Bagan 3.2 hitam-putih, menampilkan **semua variabel** (diteliti = penuh, tidak diteliti = putus-putus), caption di bawah?
10. **Jumlah & isi hipotesis 3.3 mencerminkan rumusan masalah BAB I**, kalimat positif, bernomor?

Bila satu butir gagal, perbaiki **penalaran/isinya** (perjelas logika, kembalikan fakta empirik ke BAB I/II, samakan hipotesis dengan rumusan masalah), bukan sekadar mengganti kata.
