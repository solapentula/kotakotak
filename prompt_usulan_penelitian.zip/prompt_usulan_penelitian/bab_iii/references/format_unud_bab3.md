# Format & bahasa UNUD 2024 untuk BAB III (acuan ringkas)

Skrip `build_bab3.py` sudah menegakkan sebagian besar aturan ini. Acuan bila perlu memeriksa detail.

## Struktur bab
- Judul bab: **BAB III** lalu **KERANGKA BERPIKIR, KONSEP PENELITIAN DAN HIPOTESIS PENELITIAN** (kapital, tebal, simetris/center di awal halaman).
- Subbab: **3.1 Kerangka Berpikir**, **3.2 Konsep Penelitian**, **3.3 Hipotesis** — rata kiri, tebal, dengan nomor dan tab.
- Urutan isi mengikuti panduan: kerangka berpikir → konsep (bagan) → hipotesis.

## Halaman & huruf
- Kertas **A4**; margin **kiri 4 cm**, **atas/bawah/kanan 3 cm**.
- **Times New Roman 12 pt**, spasi **1,5** untuk isi. Caption bagan & daftar 1 spasi.
- Paragraf isi **rata kanan-kiri (justify)**, indentasi baris pertama ~1,27 cm.
- Nomor halaman di tengah bawah.

## 3.1 Kerangka Berpikir
- **4 paragraf**, sintesis **deduktif + induktif**, **TANPA sitasi**.
- Tidak memuat bullet/dash; murni paragraf naratif penalaran.

## 3.2 Konsep Penelitian
- **Uraian kualitatif** (paragraf) yang merujuk bagan, menyebut semua variabel + arti garis.
- **Bagan** = kode **mermaid hitam-putih**: node `fill:#ffffff,stroke:#000000,color:#000000`; jalur diteliti `-->` (kotak garis penuh), tidak diteliti `-.->` (kotak garis putus-putus, `stroke-dasharray`); `linkStyle default stroke:#000000`.
- **Caption "Bagan 3.1. <judul>" di BAWAH bagan**, simetris (center), spasi 1 — kaidah caption gambar/bagan UNUD. Skrip menaruhnya otomatis.
- Skrip me-render kode mermaid dalam kotak monospace di docx **dan** menulis berkas `.mmd`. Bagan dirender user (mis. mermaid.live) lalu ditempel sebagai Bagan 3.1; skrip tidak menyematkan gambar otomatis.

## 3.3 Hipotesis
- **Daftar bernomor** (1., 2., 3., …) — **bukan** bullet/dash (Pedoman melarang bullet/dash untuk perincian).
- **Kalimat positif** yang menyatakan hubungan/perbedaan antar-variabel yang dapat diuji.
- **Jumlah = jumlah rumusan masalah BAB I**; urutan & isi bercermin pada rumusan masalah dan luaran BAB II.

## Bahasa
- **Pasif & impersonal**, Bahasa Indonesia baku; tanpa "saya/kami/kita/Anda".
- **Istilah asing miring** (tandai `*asterisk*` di JSON); akronim baku (VATS, ESP, MTP, ICU, PCA, QoR-15) tidak.
- Ikuti `ai_tells.md` agar prosa tidak terdengar seperti AI dan koheren dengan BAB I–II.

## Di luar BAB III
- **Metode Penelitian** (rancangan, populasi/sampel, prosedur, analisis) bukan materi BAB III. Jangan ditambahkan.
