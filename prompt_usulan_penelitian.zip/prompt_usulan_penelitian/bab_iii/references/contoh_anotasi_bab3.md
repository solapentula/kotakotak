# Contoh BAB III yang baik — anotasi kerangka berpikir deduktif/induktif

Ini BAB III dari contoh penelitian (perbandingan blok MTP vs ESP pada VATS), disusun mengikuti pola usulan Departemen yang diterima penguji. Pakai sebagai **kalibrasi nada, kepadatan, pola penalaran, dan cara membangun bagan + hipotesis** — bukan untuk disalin mentah. Perhatikan: kalimat padat, penalaran bertanda jelas, **tanpa sitasi**, istilah konsisten dengan BAB I–II, pasif, dan tiap paragraf menggeser argumen menuju rasionale. Versi utuhnya ada di `scripts/contoh_input.json`.

Alur 3.1 = corong penalaran: **premis teoretis (deduktif) → prediksi terarah (deduktif) → keterbatasan bukti (induktif) → rasionale & arah (induktif)**.

---

## 3.1 Kerangka Berpikir (4 paragraf, TANPA SITASI)

**Paragraf 1 — Premis teoretis/patofisiologis (DEDUKTIF).**
> Nyeri pasca VATS bersifat multimodal: bersumber dari trauma somatik pada dinding toraks, rangsangan viseral akibat manipulasi pleura dan parenkim paru, serta nyeri alih pada bahu yang ditimbulkan oleh iritasi diafragma. Kompleksitas ini menuntut teknik analgesia regional yang mampu menjangkau seluruh komponen tersebut secara simultan. Teknik yang hanya memblokade komponen somatik secara logis akan meninggalkan celah analgesia ... Pemahaman patofisiologis inilah yang mendasari kebutuhan untuk mengevaluasi teknik blok berdasarkan kemampuannya memblokade bukan satu, melainkan seluruh jalur nosiseptif yang terlibat.

*Anotasi:* tegakkan kerangka mekanistik (somatik–viseral–simpatetik) → tarik implikasi logis yang membatasi pilihan teknik. Nol sitasi. Penanda deduktif: "secara logis akan", "mendasari kebutuhan".

**Paragraf 2 — Prediksi terarah (DEDUKTIF).**
> Kedua teknik ... berbeda secara mendasar dalam posisi anatomis titik injeksinya relatif terhadap TPVS ... Blok ESP menempatkan obat pada bidang fasia superfisial ... pencapaian komponen viseral bergantung pada difusi melewati barier ligamen yang padat, suatu proses yang secara teoritis tidak konsisten. Blok MTP menempatkan ujung jarum ... lebih dekat ke TPVS ... Berdasarkan prinsip anatomis dan farmakologis, blok MTP secara teoritis diprediksi memberikan analgesia yang lebih menyeluruh ... dibandingkan blok ESP.

*Anotasi:* terapkan premis ke I-vs-C, uraikan perbedaan mendasar, lalu **prediksi tegas berdasarkan prinsip** (bukan data). Penanda: "secara teoritis diprediksi". Istilah konsisten dengan BAB I–II (TPVS, ESP, MTP).

**Paragraf 3 — Keterbatasan bukti (INDUKTIF).**
> Prediksi teoritis tersebut belum dapat dikonfirmasi secara klinis. Bukti yang tersedia hingga kini bersifat fragmentaris: masing-masing teknik telah diuji secara terpisah terhadap pembanding yang berbeda, pada populasi bedah yang heterogen, dan dengan luaran yang bervariasi. ... Satu-satunya perbandingan langsung yang ada dilakukan pada konteks bedah non-toraks ... sehingga hasilnya tidak dapat diekstrapolasi ke populasi VATS.

*Anotasi:* dari temuan empirik yang terserak → simpulkan bahwa pola yang ada **belum cukup**. Penanda induktif: "fragmentaris", "belum cukup untuk menyimpulkan". Tetap tanpa sitasi — ini sintesis, bukan kajian pustaka.

**Paragraf 4 — Rasionale & arah penelitian (INDUKTIF).**
> Kesenjangan antara prediksi teoritis yang mengunggulkan blok MTP dan ketiadaan bukti perbandingan langsung pada VATS membentuk rasionale utama penelitian ini. ... penelitian ini diarahkan untuk menguji kedua teknik secara langsung pada populasi VATS, dengan luaran yang mencakup konsumsi opioid, skor nyeri, *time to first rescue analgesia*, serta kualitas pemulihan menyeluruh ...

*Anotasi:* pertemukan celah teoretis-vs-empirik → **rasionale**, lalu nyatakan apa yang dilakukan + luaran. Jembatan ke 3.2 (bagan) & 3.3 (hipotesis). Luaran yang disebut **sama persis** dengan rumusan masalah BAB I.

---

## 3.2 Konsep Penelitian — uraian + bagan

*Uraian (1 paragraf):* merujuk Bagan 3.1, menyebut intervensi (MTP & ESP, level T4-T5, ropivacaine 0,375% 20 ml, pra-insisi, USG), daftar luaran, dan arti garis: **kotak penuh = diteliti, kotak putus-putus = tidak diteliti**.

*Cara membangun bagan (mermaid, hitam-putih):*
- `flowchart TD`; node hitam-putih `fill:#ffffff,stroke:#000000,color:#000000`.
- Tiga tingkat: **intervensi (atas) → faktor internal & eksternal → Luaran (bawah)**.
- Jalur/variabel **diteliti** pakai `-->` dan kotak garis penuh (`classDef diteliti`); **tidak diteliti** pakai `-.->` dan kotak garis putus-putus (`classDef takditeliti ... stroke-dasharray:5 4`).
- `linkStyle default stroke:#000000` agar semua garis hitam.
- Caption "Bagan 3.1. Konsep Penelitian" otomatis diletakkan **di bawah** oleh skrip.

---

## 3.3 Hipotesis — cermin rumusan masalah

Setiap rumusan masalah BAB I ("Apakah terdapat perbedaan ...?") menjadi satu hipotesis positif ("Terdapat perbedaan ..."). Jumlahnya sama (di sini 4):
> 1. Terdapat perbedaan total konsumsi *fentanyl* melalui PCA dalam 24 jam pertama antara kelompok blok MTP dan ESP pasca VATS.
> 2. Terdapat perbedaan skor nyeri pada jam ke-0, 1, 2, 4, 6, 12, dan 24 antara kelompok blok MTP dan ESP pasca VATS.
> 3. Terdapat perbedaan *time to first rescue analgesia* antara kelompok blok MTP dan ESP pasca VATS.
> 4. Terdapat perbedaan skor kualitas pemulihan pada 24 jam pascaoperasi antara kelompok blok MTP dan ESP pasca VATS.

*Anotasi:* kalimat positif, dapat diuji, bernomor (bukan bullet). Penomoran & isi **bercermin** pada rumusan masalah dan luaran BAB II.

---

## Yang membuatnya tidak terdengar seperti AI
Bandingkan dengan katalog di `ai_tells.md`:
- **Penalaran orisinal, bukan parafrase BAB II.** Tiap paragraf melakukan satu kerja logis (premis → prediksi → keterbatasan → rasionale), bukan meringkas ulang literatur.
- **Tanpa sitasi di 3.1** — bila ada `(Penulis, Tahun)`, materinya salah tempat.
- **Penanda logika eksplisit** ("secara logis akan", "secara teoritis diprediksi", "belum cukup untuk menyimpulkan") menggantikan penekanan kosong.
- **Istilah konsisten** dengan BAB I–II (TPVS, MTP, ESP, *time to first rescue analgesia*) — tanpa variasi sinonim.
- **Tanpa penekanan-kosong, paralelisme negatif hiasan, tiga-serangkai, atau penutup "tantangan & prospek"**.
- **Hipotesis = cermin rumusan masalah**; bagan hitam-putih menampilkan semua variabel (diteliti vs tidak diteliti). Koheren = benang merah BAB I → II → III terjaga.
