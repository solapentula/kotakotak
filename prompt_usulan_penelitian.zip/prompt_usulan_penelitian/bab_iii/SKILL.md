---
name: babkerangka
description: "Menyusun BAB III KERANGKA BERPIKIR, KONSEP PENELITIAN DAN HIPOTESIS PENELITIAN usulan penelitian sesuai Panduan Penulisan Pascasarjana Universitas Udayana 2024, untuk residen Anestesiologi & Terapi Intensif. WAJIB pakai skill ini setiap kali user mengetik `/babkerangka` atau `/babtiga`, ATAU meminta dibuatkan/diperbaiki Kerangka Berpikir, Konsep Penelitian, bagan/diagram konsep, atau Hipotesis usulan penelitian/tesis/proposal di bidang anestesi, ICU, perioperatif, hemodinamik, nyeri, sepsis, syok, atau terapi intensif. Juga gunakan ketika user sudah punya BAB I dan/atau BAB II selesai (mis. keluaran dari /babpendahuluan dan /babtinjauan) dan ingin diteruskan ke penulisan BAB III dalam format docx. Output utamanya adalah file .docx siap-pakai (kerangka berpikir 4 paragraf tanpa sitasi, bagan konsep dalam kode mermaid hitam-putih, hipotesis bernomor yang mencerminkan rumusan masalah) plus berkas .mmd, bukan jawaban di chat."
license: Proprietary
---

# Penyusun BAB III KERANGKA BERPIKIR, KONSEP & HIPOTESIS — Usulan Penelitian UNUD 2024

## Apa yang dihasilkan skill ini

Sebuah file **.docx** berisi BAB III yang lolos pembacaan penguji (Spesialis Anestesiologi & Terapi Intensif Konsultan), terdiri atas tiga subbab:

- **3.1 Kerangka Berpikir** — **4 paragraf**, sintesis **deduktif + induktif**, **TANPA sitasi** (murni penalaran penulis).
- **3.2 Konsep Penelitian** — uraian kualitatif singkat + **bagan dalam kode mermaid** (hitam-putih; garis penuh = diteliti, garis putus-putus = tidak diteliti), dengan caption "Bagan 3.1" di bawahnya.
- **3.3 Hipotesis** — daftar **bernomor**, kalimat **positif**, jumlah & isinya **mencerminkan Rumusan Masalah BAB I**.

Skrip juga menulis berkas **`.mmd`** bersebelahan dengan docx agar bagan dapat dirender terpisah.

Formatting (A4, Times New Roman 12, spasi 1,5, margin kiri 4 cm / atas-bawah-kanan 3 cm, heading bab, subbab tebal, daftar bernomor, istilah asing miring) ditangani otomatis oleh `scripts/build_bab3.py`. **Tugas Anda menulis isinya dengan benar; skrip yang merapikannya.** Jangan mengetik docx secara manual.

### Hubungan dengan Panduan UNUD (penting)

Panduan UNUD 2024 menempatkan **Kerangka Berpikir, Konsep Penelitian, dan Hipotesis di BAB III** (untuk usulan penelitian empiris). Definisi panduan yang dipatuhi skill ini:

- **Kerangka Berpikir** = hasil abstraksi dan sintesis teori dari kajian pustaka yang dikaitkan dengan masalah penelitian, disusun dengan **proses berpikir deduktif** (mengkaji teori universal) **dan induktif** (menggeneralisasi temuan empirik). Inilah "alur pikir" peneliti, bukan ringkasan ulang BAB II.
- **Konsep Penelitian** = abstraksi/sintesis teori dalam bentuk **bagan/model** yang menampilkan **semua variabel** yang berpengaruh, dilengkapi **uraian kualitatif**.
- **Hipotesis** = pernyataan ilmiah dalam **kalimat positif** yang menyatakan hubungan antar dua variabel atau lebih, yang dapat diukur dan diuji.

**Benang merah wajib.** Panduan menuntut konsistensi koheren antara judul, latar belakang, rumusan masalah, tinjauan pustaka, kerangka berpikir, konsep, dan hipotesis. BAB III **tidak boleh** memperkenalkan variabel/konsep baru yang tak ada di BAB I–II.

**Di luar cakupan skill ini:** Metode Penelitian (rancangan, populasi-sampel, prosedur, analisis statistik) berada di **BAB IV** (atau bab metode sesuai struktur prodi), bukan BAB III. Jangan menambahkannya.

---

## Alur kerja

### Langkah 1 — Pahami penelitiannya (intake)

Skill menulis akurat hanya bila studinya jelas, dan **paling baik bila BAB I & BAB II sudah ada** (sumber terbaik karena rumusan masalah dan sintesis literaturnya langsung dipakai). Kumpulkan dari pesan user, berkas project, atau riwayat percakapan (mis. keluaran `/babpendahuluan` & `/babtinjauan`). Bila ada yang hilang dan menentukan isi bab, tanyakan **sekali** secara ringkas:

- **Judul** penelitian.
- **PICO & luaran**: Populasi, Intervensi, Komparator, dan **daftar luaran utama beserta instrumen/waktu ukur** (mis. konsumsi opioid 24 jam, skor nyeri pada jam tertentu, *time to first rescue analgesia*, QoR-15).
- **Rumusan Masalah BAB I** (kalimat tanya) — sumber langsung penomoran hipotesis.
- **Mekanisme/teori penghubung** dari BAB II yang menjelaskan *mengapa* intervensi diprediksi unggul (jembatan deduktif).
- **Variabel perancu/faktor** yang diteliti vs tidak diteliti (untuk bagan konsep).

### Langkah 2 — Susun penalaran (tanpa riset sitasi baru)

Berbeda dari BAB I & II, **3.1 tidak memuat sitasi**. Materinya adalah **sintesis penalaran** dari fakta yang sudah ditegakkan di BAB I–II. Jangan menambah klaim empirik baru yang butuh rujukan; bila sebuah fakta belum ada di BAB I–II tetapi diperlukan, kembalikan ke bab tersebut, jangan menyisipkannya di sini. Sebelum menulis, baca `references/contoh_anotasi_bab3.md` untuk menyerap **nada, kepadatan, dan ritme** yang sudah diterima penguji, dan `references/ai_tells.md` untuk menghindari prosa AI.

### Langkah 3 — Tulis isi ketiga subbab

Ikuti cetak biru di bawah. Periksa detail format di `references/format_unud_bab3.md` bila perlu.

### Langkah 4 — Render, validasi, sajikan

Susun isi sebagai satu file JSON, jalankan skrip (lihat **Output**), validasi, lalu `present_files` dokumen + berkas .mmd beserta ringkasan singkat.

---

## Cetak biru 3.1 Kerangka Berpikir (4 paragraf: deduktif + induktif)

Kerangka berpikir adalah **corong penalaran** dari teori menuju rasionale penelitian. Dua paragraf bersandar pada penalaran **deduktif** (dari prinsip/teori universal ke prediksi spesifik), dua lainnya pada penalaran **induktif** (dari temuan empirik yang terserak ke kesimpulan tentang adanya celah). Urutannya boleh deduktif→induktif **atau** sebaliknya — pilih yang menghasilkan nada paling mengalir dan paling tidak generik. **Tanpa sitasi sama sekali.**

**Paragraf deduktif-1 — Premis teoretis/patofisiologis.**
Tegakkan kerangka mekanistik yang menjadi taruhan: anatomi/fisiologi/farmakologi yang menentukan keberhasilan luaran. Tutup dengan implikasi logis yang membatasi pilihan teknik/intervensi.

**Paragraf deduktif-2 — Prediksi terarah.**
Terapkan premis itu pada intervensi vs komparator: jelaskan perbedaan mendasar keduanya, lalu **prediksi teoritis** mana yang seharusnya unggul **dan mengapa** (berdasarkan prinsip, bukan data). Akhiri dengan pernyataan prediksi yang tegas.

**Paragraf induktif-1 — Keterbatasan bukti yang ada.**
Nyatakan bahwa prediksi itu belum terkonfirmasi: bukti empirik bersifat fragmentaris (teknik diuji terpisah, populasi heterogen, luaran berbeda). Tunjukkan mengapa pola yang ada belum cukup menyimpulkan keunggulan relatif.

**Paragraf induktif-2 — Rasionale & arah penelitian.**
Pertemukan kesenjangan teoretis-vs-empirik menjadi **rasionale utama**. Nyatakan apa yang akan dilakukan penelitian ini (perbandingan langsung pada populasi spesifik) dan luaran yang dinilai. Paragraf ini menjadi jembatan ke 3.2 dan 3.3.

> Catatan jumlah: target **tepat 4 paragraf**. Bila intervensi tunggal (bukan perbandingan), pertahankan struktur deduktif→induktif: premis teori → prediksi efek → keterbatasan bukti → rasionale.

---

## Cetak biru 3.2 Konsep Penelitian (uraian + bagan mermaid)

Sediakan **1 paragraf uraian kualitatif** yang merujuk ke Bagan 3.1, menyebut intervensi, luaran utama, dan arti garis penuh vs putus-putus. Lalu bagan dalam **kode mermaid**.

**Aturan bagan (kaidah UNUD + permintaan):**
- **Hitam-putih saja**: setiap node `fill:#ffffff,stroke:#000000,color:#000000`. Tanpa warna lain.
- **Garis penuh = variabel/jalur diteliti; garis putus-putus = tidak diteliti.** Pakai `-->` untuk diteliti dan `-.->` untuk tidak diteliti. Kotak diteliti `classDef` bergaris penuh; kotak tidak diteliti bergaris putus-putus (`stroke-dasharray`).
- **`linkStyle default stroke:#000000`** agar semua garis hitam.
- **Caption "Bagan 3.1. <judul>" diletakkan di BAWAH bagan** (kaidah gambar/bagan UNUD) — skrip yang menaruhnya; Anda cukup isi `nomor` & `caption`.
- Struktur kanonik (boleh diadaptasi sesuai penelitian): **lengan intervensi (atas) → faktor internal & eksternal (diteliti = garis penuh, tidak diteliti = putus-putus) → Luaran (bawah)**. Sertakan rincian dosis/level pada node intervensi dan daftar luaran lengkap pada node Luaran.

Skrip me-render kode mermaid sebagai **kotak monospace** di dalam docx **dan** menulis berkas **`.mmd`**. User me-render bagan (mis. di mermaid.live atau penampil mermaid) lalu menempelkannya sebagai Bagan 3.1, atau menyerahkan docx apa adanya bila penguji menerima kode. Skrip tidak menyematkan gambar otomatis.

Contoh kerangka mermaid (hitam-putih, penuh + putus-putus) ada di `scripts/contoh_input.json` pada field `konsep_bagan.mermaid`.

---

## Cetak biru 3.3 Hipotesis (cermin Rumusan Masalah)

Satu kalimat pengantar opsional ("Berdasarkan kerangka berpikir di atas, hipotesis penelitian ini dirumuskan sebagai berikut:"), diikuti **daftar bernomor** (1., 2., 3., …) — **bukan** bullet/dash (Pedoman melarang bullet/dash untuk perincian).

- **Kalimat positif** yang menyatakan hubungan/perbedaan antar-variabel yang dapat diuji. Ubah tiap Rumusan Masalah BAB I ("Apakah terdapat perbedaan ...?") menjadi pernyataan ("Terdapat perbedaan ...").
- **Jumlah hipotesis = jumlah rumusan masalah = jumlah luaran utama.** Urutan & isinya **bercermin** pada Rumusan Masalah dan luaran yang dibahas di BAB II.
- Untuk uji perbedaan, default hipotesis adalah **H1 (alternatif)** dalam bentuk positif. Cantumkan H0 hanya bila prodi/penguji memintanya.

---

## Suara akademik — dan cara TIDAK terdengar seperti AI

Penguji konsultan langsung mengenali prosa generik buatan model bahasa. Khusus BAB III, taruhannya adalah **kerangka berpikir harus terbaca sebagai penalaran orisinal peneliti yang koheren dengan BAB I–II** — bukan parafrase berputar. Katalog lengkap tanda-AI + checklist uji-mandiri ada di `references/ai_tells.md` — **baca sekali sebelum menulis, jalankan checklist sebelum render**. Inti yang harus dipatuhi:

- **Pasif & impersonal, Bahasa Indonesia baku.** Tanpa "saya/kami/kita/Anda".
- **TANPA sitasi di 3.1.** Bila tergoda menulis `(Penulis, Tahun)`, itu tanda materinya seharusnya di BAB I/II. Kerangka berpikir adalah sintesis penalaran, bukan kajian pustaka ulang.
- **Penalaran bertanda jelas.** Tunjukkan logika ("secara anatomis diprediksi", "secara logis akan", "belum cukup untuk menyimpulkan") alih-alih klaim berhias. Hindari penekanan-kosong: "memegang peranan penting", "sangat krusial", "menjadi tonggak", dan frasa-AI ("lanskap", "menggarisbawahi", "komprehensif" yang menumpuk).
- **Hindari paralelisme negatif & tiga-serangkai** sebagai bumbu ("bukan hanya … tetapi juga …", daftar tiga sifat). Boleh "bukan satu, melainkan seluruh ..." bila memang bermakna logis.
- **Jaga istilah konsisten** dengan BAB I–II (mis. tetap "blok MTP", "TPVS", "*time to first rescue analgesia*"). Jangan berganti sinonim demi variasi.
- **Variasikan ritme; transisi seperlunya.** Selang-seling kalimat panjang dengan kalimat pendek tegas. "Namun", "Oleh karena itu", "Sebaliknya" hanya saat ada pertentangan/sebab-akibat nyata.
- **Tanpa editorializing & penutup formulaik.** Buang "penting untuk dicatat", "patut digarisbawahi"; jangan menutup dengan pola "masih banyak tantangan … ke depannya diharapkan …".
- **Istilah asing miring** lewat `*asterisk*` di JSON; akronim baku (VATS, ESP, MTP, ICU, PCA, QoR-15) tidak.

**Contoh kalibrasi (buruk → baik):**

> Penekanan kosong → penalaran:
> Buruk: "Manajemen nyeri pasca VATS sangat penting dan tidak dapat dipungkiri memegang peranan krusial."
> Baik: "Teknik yang hanya memblokade komponen somatik secara logis akan meninggalkan celah analgesia, sehingga kebutuhan opioid tambahan meningkat dan kualitas pemulihan menjadi suboptimal."

> Sitasi terselip → sintesis murni:
> Buruk: "Beberapa studi (Forero et al., 2016; Costache et al., 2017) menunjukkan kedua blok efektif."
> Baik: "Kedua teknik menunjukkan efektivitas pada konteksnya masing-masing, tetapi pola yang terserak ini belum cukup untuk menyimpulkan keunggulan relatif satu teknik atas yang lain."

---

## Output — render docx dengan skrip bundel

Tulis seluruh isi sebagai satu file JSON (skema persis di `scripts/contoh_input.json`), lalu jalankan skrip dari folder skill yang sedang aktif:

```bash
python <folder-skill>/scripts/build_bab3.py <input.json> /mnt/user-data/outputs/BAB_III_<topik>.docx
```

Skrip juga menulis `BAB_III_<topik>.mmd` di folder yang sama.

Skema JSON ringkas:

```json
{
  "judul": "JUDUL STUDI (konteks; tidak dicetak sebagai heading)",
  "bab_nomor": "III",
  "bab_judul": "KERANGKA BERPIKIR, KONSEP PENELITIAN DAN HIPOTESIS PENELITIAN",
  "kerangka_berpikir": ["paragraf 1", "paragraf 2", "paragraf 3", "paragraf 4"],
  "konsep_uraian": ["uraian kualitatif singkat yang merujuk Bagan 3.1 ..."],
  "konsep_bagan": {
    "nomor": "3.1",
    "caption": "Konsep Penelitian",
    "mermaid": "flowchart TD\n  A[\"...\"]\n  ...\n  classDef ... ;\n  linkStyle default stroke:#000000;",
    "sumber": ""
  },
  "hipotesis_pengantar": "Berdasarkan kerangka berpikir di atas, hipotesis penelitian ini dirumuskan sebagai berikut:",
  "hipotesis": ["Terdapat perbedaan ...", "..."],
  "referensi": []
}
```

Konvensi penting saat mengisi JSON:
- `kerangka_berpikir` berisi **4** string (satu per paragraf), **tanpa** pola sitasi `(... , tahun)`.
- Tandai istilah asing dengan `*asterisk*` agar dirender miring (berlaku di paragraf, uraian, hipotesis).
- `konsep_bagan.mermaid` harus hitam-putih (penuh + putus-putus, lihat aturan 3.2). Jangan memakai warna.
- `hipotesis` berisi **kalimat positif** (jangan diakhiri tanda tanya); jumlahnya = jumlah rumusan masalah BAB I.
- Jangan menaruh nomor manual di awal item hipotesis (skrip menomori otomatis).
- `referensi` biasanya **kosong** untuk BAB III.

Setelah render, **validasi**: skrip memunculkan peringatan bila kerangka berpikir ≠ 4 paragraf, ada sitasi di 3.1, bagan kosong, atau hipotesis berbentuk pertanyaan. Buka kembali dokumen untuk memastikan 3.1–3.3 lengkap, bagan ada, dan **tiap hipotesis bersesuaian dengan satu rumusan masalah BAB I**. Lalu `present_files` dokumen + berkas .mmd + ringkasan 2–3 kalimat (jangan tempel ulang seluruh isi bab). Ingatkan bahwa Metode Penelitian adalah materi bab berikutnya.

---

## Berkas pendukung

- `references/contoh_anotasi_bab3.md` — contoh BAB III yang sudah diterima penguji (studi MTP vs ESP), dianotasi per paragraf ke pola deduktif/induktif + cara membangun bagan + cara mencerminkan hipotesis. **Baca sebelum menulis** untuk menyamakan nada.
- `references/ai_tells.md` — katalog tanda-tanda tulisan AI (adaptasi esai *Wikipedia: Signs of AI writing*) + checklist uji-mandiri, ditekankan pada kerangka berpikir tanpa sitasi dan penalaran orisinal. **Baca sebelum menulis** dan jalankan checklist sebelum render.
- `references/format_unud_bab3.md` — rincian aturan format & bahasa UNUD 2024 untuk BAB III (subbab, daftar bernomor, bagan/caption, mermaid hitam-putih).
- `scripts/build_bab3.py` — perender docx (format UNUD otomatis) + penulis berkas .mmd.
- `scripts/contoh_input.json` — contoh input JSON lengkap (studi MTP vs ESP pada VATS) yang sekaligus jadi demo skema dan kerangka draf.
