# Contoh BAB II yang baik — anotasi 7 subbab tematik

Ini BAB II dari contoh penelitian (Ringerfundin vs salin 0,9% terhadap keseimbangan asam-basa pada KAD), disusun mengikuti pola usulan Departemen yang diterima penguji. Pakai sebagai **kalibrasi nada, kepadatan, pola sitasi, dan cara membangun tabel sintesis** — bukan untuk disalin mentah. Perhatikan: kalimat padat, angka spesifik, sitasi dekat klaim, istilah asing miring, pasif, dan tiap subbab menggeser argumen menuju gap. Setiap subbab di sini juga ada utuh di `scripts/contoh_input.json`.

Alur keseluruhan = PICO: **P**opulasi (2.1) → fisiologi yang dipertaruhkan (2.2) → **I**ntervensi (2.3) → **C**omparator (2.4) → adu I-vs-C terhadap **O**utcome + tabel (2.5) → celah (2.6) → keamanan (2.7).

---

**2.1 Populasi/kondisi — Ketoasidosis Diabetikum (1 paragraf, DENGAN SITASI).**
> Ketoasidosis diabetikum (KAD) merupakan komplikasi metabolik akut diabetes melitus yang ditandai oleh trias hiperglikemia, ketonemia, dan asidosis metabolik bertipe *high anion gap* ... (Bell & Lain, 2025). Defisiensi insulin memacu lipolisis dan ketogenesis ... Tata laksana bertumpu pada resusitasi cairan intravena dan terapi insulin ... sehingga pilihan jenis cairan menjadi penentu penting arah keseimbangan asam-basa selama resusitasi (Yan et al., 2024).

*Anotasi:* definisi + kriteria diagnostik inti + patogenesis ringkas + arahkan ke titik tempat intervensi (jenis cairan) berperan. Satu paragraf cukup. Kalimat terakhir adalah "engsel" menuju 2.2.

**2.2 Fisiologi yang dipertaruhkan — Keseimbangan Asam-Basa & Pendekatan Stewart (≤2 paragraf, DENGAN SITASI).**
> Pendekatan Stewart menilai status asam-basa dari tiga variabel independen, yakni *strong ion difference* (SID), konsentrasi total asam lemah (Atot), dan tekanan parsial karbon dioksida ... (Adrogué et al., 2022). SID plasma ... bernilai sekitar 40 mEq/L ...
>
> Pada KAD, akumulasi benda keton ... menurunkan SID dan menghasilkan asidosis ketotik (Catahay et al., 2022). Bila resusitasi memakai cairan berklorida tinggi, beban klorida menurunkan SID lebih jauh ... (Ramanan et al., 2021). Uji fisiologis acak oleh Dell'Anna et al. (2025) menegaskan mekanisme ini ...

*Anotasi:* paragraf 1 = kerangka teori (Stewart) dengan angka fisiologis (40 mEq/L); paragraf 2 = bagaimana kondisi 2.1 mengganggu kerangka itu, langsung menautkan ke komposisi cairan. "Anatomi" tidak relevan untuk topik fisikokimia — subbab dinamai sesuai isi. Inilah jembatan teoretis yang membuat pilihan cairan bermakna.

**2.3 Intervensi — Cairan *Balanced* Ringerfundin (2 paragraf, DENGAN SITASI).**
> Cairan *balanced* dikembangkan untuk mengatasi keterbatasan salin ... (Semler et al., 2018). Ringerfundin merupakan cairan *balanced* berbasis asetat dan malat ... sehingga SID-nya lebih tinggi daripada salin ...
>
> Pada konteks KAD, sejumlah studi mengaitkan cairan *balanced* dengan resolusi asidosis yang lebih cepat ... (Catahay et al., 2022; Jahangir et al., 2022; Liu et al., 2024). Studi di Indonesia oleh Aditianingsih et al. (2017) ... melaporkan SID yang lebih tinggi ... disertai SBE yang lebih baik mulai jam ke-18. ...

*Anotasi:* paragraf 1 = komposisi + dasar teoretis keunggulan pada mekanisme 2.2; paragraf 2 = bukti empirik, **menonjolkan studi Indonesia** (sangat dihargai penguji) dengan angka spesifik. Sitasi jamak diurut lama→baru.

**2.4 Komparator — Salin 0,9% (2 paragraf, DENGAN SITASI).**
> Salin 0,9% selama ini menjadi cairan resusitasi baku pada KAD ... (Catahay et al., 2022). Larutan ini mengandung natrium dan klorida masing-masing 154 mmol/L ... sehingga SID-nya bernilai nol ... (Ramanan et al., 2021). ...
>
> Pemberian salin dalam volume besar menurunkan SID plasma dan ... menurunkan pH sehingga menimbulkan asidosis metabolik hiperkloremik (Adrogué et al., 2022). ... uji SMART melaporkan *major adverse kidney events* sebesar 14,3% pada kelompok *balanced* dibanding 15,4% pada salin (Semler et al., 2018). ... Konsekuensi tersebut menempatkan salin sebagai pembanding yang relevan untuk diuji ...

*Anotasi:* paragraf 1 = status baku + komposisi (angka konkret, SID = 0); paragraf 2 = keterbatasan/risiko yang memotivasi perbandingan (angka SMART 14,3% vs 15,4%), ditutup dengan menempatkan komparator sebagai pembanding yang layak diuji. Cermin struktural dari 2.3.

**2.5 Perbandingan I-vs-C + TABEL sintesis (2 paragraf mengapit tabel, DENGAN SITASI).**
> *(paragraf pembuka)* Bukti yang membandingkan cairan *balanced* dengan salin pada KAD hingga kini masih bercampur ... Tabel 2.1 merangkum studi-studi utama yang relevan ...
>
> **[Tabel 2.1 di sini — lihat di bawah]**
>
> *(paragraf penutup)* Sintesis ini memperlihatkan pola yang konsisten pada parameter klorida dan kecenderungan resolusi asidosis yang lebih cepat pada cairan *balanced*, meskipun kemaknaan statistik tidak selalu tercapai ... Yang lebih penting, sangat sedikit penelitian yang menilai keseimbangan asam-basa KAD secara langsung melalui dekomposisi Stewart yang utuh ... Celah inilah yang menjadi sasaran penelitian ini.

*Anotasi:* paragraf pembuka menyatakan bukti bercampur + mengarahkan ke tabel; paragraf penutup **menafsirkan pola lintas-studi** lalu menunjuk persis bagian yang belum terjawab (sedikit yang pakai Stewart utuh) — menyiapkan 2.6. Tabel diletakkan **di antara** dua paragraf memakai mode `konten` berurutan.

*Cara membangun tabel sintesis:* satu baris per studi utama; kolom = Penulis (Tahun) · Desain · Populasi · Perbandingan · Luaran asam-basa utama · Hasil. Isi sel = **ringkasan hasil dalam kata sendiri + angka nyata** (HR 1,46; IK 95% 1,10–1,94 dari Catahay; MAKE 14,3% vs 15,4% dari SMART), bukan kutipan. Frasa pendek, bukan kalimat. Field `sumber` diisi "Disusun dari ..." mendaftar semua studi. Skrip merender judul di atas, garis tiga-baris, sumber di bawah, sel 10 pt.

**2.6 Justifikasi (1 paragraf, SITASI minimal).**
> Hingga saat ini belum ada data yang membandingkan Ringerfundin dengan salin 0,9% menggunakan SID dan SBE secara serial pada pasien KAD, khususnya di RS Ngoerah ... Penelitian terdahulu umumnya menilai luaran klinis agregat atau memakai cairan dan instrumen yang berbeda ... (Aditianingsih et al., 2017; Ramanan et al., 2021). Penelitian ini dirancang untuk mengisi celah tersebut dengan mengukur SID dan SBE pada jam ke-0, ke-6, dan ke-24 ...

*Anotasi:* celah eksplisit (data pembanding langsung dengan instrumen tepat + ketiadaan protokol institusi) → apa yang akan dilakukan. Menggemakan gap BAB I tapi dari sudut bukti literatur. Jembatan ke BAB III.

**2.7 Keamanan (2 paragraf, DENGAN SITASI).**
> Profil keamanan cairan *balanced* pada KAD menjadi perhatian khusus karena kekhawatiran bahwa anion penyangga seperti asetat dapat memicu ketogenesis. Kekhawatiran ini terbantahkan oleh SCOPE-DKA ... (Ramanan et al., 2021). ...
>
> Sebaliknya, salin 0,9% membawa risiko asidosis hiperkloremik dan ... peningkatan kejadian ginjal merugikan akibat beban klorida (Semler et al., 2018). Terlepas dari jenis cairan, resusitasi KAD menuntut pemantauan ketat kalium dan glukosa ...

*Anotasi:* paragraf 1 = bantah kekhawatiran intervensi dengan bukti; paragraf 2 = risiko komparator + pemantauan yang tetap perlu terlepas dari lengan. Menutup bab dengan nada klinis bertanggung jawab.

---

## Yang membuatnya tidak terdengar seperti AI
Bandingkan dengan katalog di `ai_tells.md` — contoh ini lolos justru karena menghindari pola-pola berikut:
- Tiap subbab punya **satu pekerjaan** dalam alur PICO; tidak ada paragraf pengisi atau analisis dangkal.
- **Angka di mana-mana** (40 mEq/L, 154 mmol/L, SID = 0, HR 1,46, 14,3% vs 15,4%, jam ke-18/ke-0/ke-6/ke-24) — bukan klaim umum.
- **Atribusi bernama, bukan samar.** Studi disebut dengan namanya (SMART, SCOPE-DKA, BRISK-ED, Aditianingsih); tidak ada "beberapa studi/para ahli" tanpa `(Penulis, Tahun)`.
- **Sintesis, bukan daftar.** 2.5 menafsirkan pola lintas-studi lalu menunjuk celah; tabel sintesis **memikul beban "tinjauan hasil penelitian terkait"** — bukan hiasan.
- **Istilah & nama studi konsisten** (SID tetap "SID", SMART tetap "SMART") — tanpa variasi sinonim demi keragaman.
- **Tanpa penekanan-kosong, paralelisme negatif, atau tiga-serangkai** ("memegang peranan penting", "bukan hanya … tetapi juga …", daftar tiga sifat).
- Sitasi **dekat klaim**, istilah asing miring, kalimat pasif, ritme bervariasi; **tanpa penutup formulaik** "tantangan & prospek masa depan".
- **Tidak ada** Kerangka Konsep/Hipotesis (itu BAB III).
