# Aturan format & bahasa — Panduan UNUD 2024 (intisari untuk BAB II)

Skrip `build_bab2.py` sudah menegakkan sebagian besar ini. Acuan bila perlu memeriksa detail. Penekanan khusus pada **tabel** dan **gambar** karena keduanya inti BAB II.

## Naskah & halaman
- Kertas A4 (21 × 29,7 cm), HVS 80 g/m², putih, tidak bolak-balik.
- Margin: **kiri 4 cm**, **atas 3 cm**, **bawah 3 cm**, **kanan 3 cm**.
- Nomor halaman bagian inti: angka Arab; **halaman bab** → tengah bawah. (Skrip memakai tengah-bawah karena BAB II diawali halaman bab.)

## Huruf, spasi, paragraf
- Times New Roman **12 pt** seluruh naskah isi.
- Spasi **1,5** untuk isi. Spasi **1** untuk daftar referensi, judul/isi tabel, caption gambar, dan daftar-daftar.
- Indentasi baris pertama paragraf ≈ **1,27 cm** (ketukan ke-7).
- Bahasa Indonesia baku; **kalimat pasif**, tanpa orang pertama/kedua.
- Istilah asing/daerah dicetak **miring** (*italic*) — tandai `*begini*` di JSON.

## Bilangan & satuan
- Bilangan < 10 atau di awal kalimat ditulis huruf; selebihnya angka.
- Desimal pakai **koma** (mis. 14,3%), bukan titik. Ukuran efek tetap apa adanya (HR 1,46; IK 95% 1,10–1,94).
- Satuan tanpa titik (mmol/L, mEq/L, mg, mL).

## Judul bab & subbab
- **Judul bab**: halaman baru, KAPITAL semua, tebal, rata tengah, tanpa titik. Nomor bab Romawi (BAB II). Baris kedua = nama bab (TINJAUAN PUSTAKA).
- **Subbab** (2.1, 2.2, …): tepi kiri, **tebal**, tanpa titik akhir; Title Case (kapital tiap kata kecuali kata sambung/depan).
- **Anak subbab** (2.3.1, …): tepi kiri, **tebal**.
- **Anak-anak subbab** (2.3.1.1, …): tepi kiri, **tidak tebal**.
- Skrip menentukan tebal/tidak otomatis dari kedalaman `nomor`.

## Perincian ke bawah
- Pakai **nomor/huruf** (1., 2., a., b.). **Dilarang** tanda hubung (-) atau bullet.

## Tabel (KRITIS untuk BAB II)
- **Judul tabel di ATAS tabel**, rata tengah: "Tabel 2.1 Judul tabel". Spasi 1.
- **Hanya garis horizontal — gaya tiga-garis:** garis di atas baris header, garis di bawah header, garis di bawah baris terakhir. **Tanpa garis vertikal** dan **tanpa garis antar-baris isi**. Skrip menegakkan ini (`tblBorders` semua none, lalu border atas+bawah header dan bawah baris akhir).
- **Baris "Sumber:" tepat di bawah tabel**, spasi 1, ukuran kecil. Untuk tabel olahan sendiri: "Disusun dari Penulis (Tahun); ...".
- Penomoran per bab: tabel pertama di BAB II = Tabel 2.1, lalu 2.2, dst.
- **Diusahakan muat satu halaman.** Sel dirender **10 pt**. Isi sel ringkas (frasa, bukan kalimat panjang). Header sel tebal.
- Bila tabel dirujuk dalam teks, sebut nomornya ("Tabel 2.1 merangkum ...") dan letakkan dekat paragraf perujuk (pakai mode `konten` berurutan).

## Gambar
- **Caption di BAWAH gambar**, rata tengah: "Gambar 2.1 Keterangan". Spasi 1. Diikuti baris sumber bila ada.
- Skrip **tidak menyematkan gambar berhak cipta**: menulis penanda "[Sisipkan Gambar X di sini]" agar user menempel gambar berlisensi/milik sendiri secara manual.
- Hindari mereproduksi figur paper; sarankan menggambar ulang skema bila perlu.

## Sumber & sitasi
- Gaya: **APA edisi ke-7** (in-text identik Harvard).
- In-text: nama akhir saja; 2 penulis sebut keduanya; >2 → penulis pertama + `et al.`/`dkk.`. Tahun dalam kurung. Sumber jamak dalam satu kurung diurut lama→baru, dipisah titik koma.
- Rujukan **≤10 tahun**, diutamakan jurnal terakreditasi/internasional. Sumber asli/penemu (mis. deskripsi pertama pendekatan Stewart) boleh lebih lama.
- Letakkan rujukan sedekat mungkin dengan klaimnya, bukan menumpuk di akhir paragraf.

## Daftar referensi (APA 7) — alat bantu di akhir dokumen
- Urut alfabetis nama akhir; **hanging indent**; nama jurnal & volume **miring**; sertakan DOI bila ada. Spasi 1.
- Hanya cantumkan sumber yang **benar-benar dikutip** dan **benar-benar ada**.
- Contoh artikel jurnal:
  Semler, M. W., Self, W. H., Wanderer, J. P., ... Rice, T. W. (2018). Balanced crystalloids versus saline in critically ill adults. *The New England Journal of Medicine*, *378*(9), 829–839. https://doi.org/10.1056/NEJMoa1711584

## Batas cakupan BAB II
- Isi BAB II = **landasan teoritis + tinjauan hasil penelitian terkait** (di skill ini diwujudkan sebagai subbab tematik 2.1–2.7).
- **Kerangka Berpikir, Kerangka Konsep, dan Hipotesis = BAB III**, bukan BAB II. Jangan dimasukkan.
