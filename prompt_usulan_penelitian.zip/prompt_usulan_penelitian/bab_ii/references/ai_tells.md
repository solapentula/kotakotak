# Tanda-tanda tulisan AI — dan cara menghindarinya (BAB II)

Acuan ringkas untuk memastikan Tinjauan Pustaka **tidak terbaca seperti keluaran model bahasa**. Disarikan dan diadaptasi dari esai *Wikipedia: Signs of AI writing* ke konteks usulan penelitian anestesi/ICU berbahasa Indonesia. **Baca sekali sebelum menulis**, lalu pakai checklist di akhir sebagai uji-mandiri sebelum render. Pada BAB II, taruhannya lebih tinggi: bab ini berbasis literatur, jadi **atribusi samar dan sintesis dangkal** adalah tanda AI yang paling cepat dikenali penguji.

> **Peringatan penting (jangan jadi pemburu kata kunci).** Tidak ada satu kata pun yang otomatis "haram". Tujuannya **bukan** menghapus daftar kata, melainkan menulis sintesis yang **berangka, bernama studi, dan bersitasi** sehingga tanda-tanda ini hilang sendiri. Satu-dua frasa di bawah bisa muncul wajar; yang menjadi tanda AI adalah **kepadatannya** dalam satu paragraf. Sebagian kata (mis. "signifikan" untuk kemaknaan statistik, "robust" untuk desain metode) sah pada tempatnya — yang dilarang pemakaian dekoratif tanpa isi.

---

## A. Tanda pada ISI (content)

**A1. Penekanan berlebihan pada signifikansi/peran.**
Menyatakan sesuatu "sangat penting / berperan vital / menjadi tonggak" tanpa data. Landasan teori dinilai dari mekanisme + angka, bukan kata sifat.
- Buruk: "Cairan resusitasi memegang peranan yang sangat penting dan krusial dalam tata laksana KAD."
- Baik: "Salin 0,9% mengandung klorida 154 mmol/L sehingga SID-nya bernilai nol, dan volume besar menurunkan pH sesuai prinsip Stewart (Adrogué et al., 2022)."

**A2. Bahasa promosi / puffery.**
"Cairan generasi terbaru", "solusi unggul", "terobosan" — buang. Sebut komposisi, mekanisme, dan bukti.

**A3. Atribusi samar & overgeneralisasi opini.** *(paling merusak — BAB II berbasis sitasi)*
"Beberapa studi menunjukkan", "banyak penelitian membuktikan", "para ahli sepakat", "secara umum diterima" — tanpa nama studi/tahun. Setiap klaim empirik harus menempel `(Penulis, Tahun)` nyata; studi besar sebut namanya (SMART, SCOPE-DKA, BRISK-ED).
- Buruk: "Beberapa studi mengaitkan cairan balanced dengan resolusi asidosis lebih cepat."
- Baik: "Resolusi asidosis lebih cepat pada cairan *balanced* dilaporkan oleh tiga studi (Catahay et al., 2022; Jahangir et al., 2022; Liu et al., 2024)."

**A4. Sintesis dangkal (bukan sekadar daftar).**
Paragraf yang menjejer ringkasan studi satu per satu tanpa menafsirkan polanya ("Studi A menemukan X. Studi B menemukan Y."). Inti 2.5 adalah **menafsirkan pola lintas-studi** lalu menunjuk persis bagian yang belum terjawab. Tabel sintesis memikul beban "tinjauan hasil penelitian terkait", bukan hiasan.

**A5. Penutup formulaik "tantangan & prospek masa depan".**
Hindari "Meski demikian, masih banyak tantangan ... di masa depan diharapkan ...". Subbab 2.6 menutup dengan **celah eksplisit + apa yang akan diisi penelitian ini**, sebagai jembatan ke BAB III.

---

## B. Tanda pada BAHASA & TATA KALIMAT

**B1. Densitas tinggi "kosakata-AI".**
Padanan Indonesia yang patut diwaspadai (pakai hemat, jangan menumpuk):

> *lanskap* (metafora), *menggarisbawahi*, *menyoroti*, *menjadi bukti / testament*, *tak terbantahkan / tidak dapat dipungkiri*, *memainkan peran (penting/krusial/vital/pivotal)*, *secara signifikan* (di luar makna statistik), *komprehensif*, *holistik*, *mendalam*, *rumit/kompleks nan*, *kaya akan*, *beragam / berbagai macam*, *di era modern ini*, *seiring perkembangan zaman*, *di tengah*, *pada akhirnya*, *yang patut dicatat*, *menjembatani kesenjangan*, *membuka jalan bagi*, *meningkatkan (enhance)*, *mengoptimalkan*, *mumpuni*, *tonggak / babak baru*.

**B2. Paralelisme negatif.**
"**bukan hanya … tetapi juga …**" dan "**bukan … melainkan …**" untuk efek retoris. Berulang = tanda AI. Ubah jadi pernyataan langsung berdata.

**B3. Pola tiga-serangkai (*rule of three*).**
Daftar tiga sifat yang dipaksakan ("aman, efektif, dan terjangkau"). Sebut yang bermakna dengan angkanya.

**B4. Variasi elegan (*elegant variation*) — khusus berbahaya di tulisan ilmiah.**
Mengganti-ganti sebutan untuk istilah yang harus **konsisten**. Sekali "*strong ion difference* (SID)", seterusnya "SID" — jangan berselang-seling "selisih ion kuat / parameter ionik / nilai ion". Sebut studi dengan nama yang sama setiap kali (mis. selalu "SMART", bukan kadang "uji Semler").

**B5. Penghindaran kopula sederhana / over-nominalisasi.**
Pilih kata kerja langsung; pasif baku tetap boleh. Hindari frasa benda berlapis ("melakukan evaluasi terhadap pemberian" → "mengevaluasi pemberian").

---

## C. Tanda pada GAYA, TRANSISI & MARKUP

**C1. Penjejalan transisi.**
"Selain itu", "Lebih lanjut", "Selanjutnya", "Di sisi lain" di tiap awal kalimat. Pakai hanya saat ada sebab-akibat/pertentangan nyata.

**C2. Editorializing / hedging klise.**
"Penting untuk dicatat bahwa", "perlu digarisbawahi", "patut dicatat", "menariknya". Hapus; sampaikan faktanya.

**C3. Ritme kalimat seragam.**
Selang-seling kalimat kompleks dengan kalimat pendek yang tegas.

**C4. Markup yang tak diminta (skrip yang merender format).**
Jangan menaruh **boldface**, *Title Case*, em dash (—) dekoratif, kutip melengkung, atau emoji di teks JSON. Miring hanya untuk istilah asing via `*asterisk*` (termasuk di sel tabel). Sel tabel berisi **frasa pendek + angka**, bukan kalimat panjang atau kutipan verbatim. Penomoran subbab/tabel ditangani skrip.

---

## Checklist uji-mandiri (jalankan sebelum render)

1. Setiap klaim empirik punya `(Penulis, Tahun)` nyata — tidak ada "beberapa studi/para ahli" tanpa nama?
2. Studi besar disebut dengan namanya (SMART, SCOPE-DKA, dst.) — menunjukkan penguasaan literatur?
3. Subbab 2.5 menafsirkan **pola lintas-studi**, bukan sekadar mendaftar studi satu per satu?
4. Tabel sintesis berisi ringkasan kata-sendiri + angka nyata (HR, IK 95%, %), bukan kutipan verbatim?
5. Tidak ada frasa B1 yang menumpuk (maks sesekali, selalu berisi)?
6. Tidak ada "bukan hanya … tetapi juga …" atau tiga-serangkai yang dipaksakan?
7. Istilah teknis & nama studi konsisten dari awal sampai akhir (tanpa variasi sinonim)?
8. Tidak ada "penting untuk dicatat / tidak dapat dipungkiri / seiring perkembangan zaman"?
9. Tidak ada penutup "tantangan & prospek masa depan" yang formulaik di 2.6?
10. Tidak ada Kerangka Konsep/Hipotesis (itu materi BAB III)? Bandingkan kepadatan dengan `contoh_anotasi_bab2.md`.

Bila satu butir gagal, perbaiki **isinya** (tambah angka/sitasi/nama studi nyata, buang frasa kosong), bukan sekadar mengganti kata.
