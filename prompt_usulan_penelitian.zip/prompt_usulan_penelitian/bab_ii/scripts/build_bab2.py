#!/usr/bin/env python3
"""
build_bab2.py — Render BAB II TINJAUAN PUSTAKA (usulan penelitian) ke .docx
sesuai Panduan Penulisan Pascasarjana Universitas Udayana 2024.

Pemakaian:
    python scripts/build_bab2.py <input.json> <output.docx>

Format yang ditegakkan otomatis:
- Kertas A4, margin kiri 4 cm / atas-bawah-kanan 3 cm
- Times New Roman 12 pt, spasi 1,5 (isi); tabel, judul tabel/gambar & daftar
  referensi 1 spasi
- Heading "BAB II" + "TINJAUAN PUSTAKA" kapital, tebal, simetris di awal halaman
- Subbab (2.1 dst.) rata kiri, tebal, Title Case; anak subbab (2.1.1) tebal
  sentence case; anak-anak subbab (2.1.1.1) biasa (tidak tebal)
- Paragraf isi rata kanan-kiri (justify), indentasi baris pertama ~1,27 cm
- Istilah yang ditandai *miring* dirender italic (berlaku juga di sel tabel)
- TABEL gaya UNUD: judul simetris DI ATAS tabel, hanya garis horizontal
  (atas kepala, bawah kepala, bawah tabel) tanpa garis vertikal, baris
  "Sumber:" di bawah tabel
- GAMBAR (opsional): caption simetris DI BAWAH gambar; skrip menyisipkan
  penanda tempat gambar yang bisa diganti gambar asli oleh penulis
- Penomoran daftar otomatis (angka/huruf, bukan bullet/dash)

Skema JSON (ringkas):
{
  "judul": "JUDUL STUDI (untuk nama berkas/konteks, tidak dicetak sebagai heading)",
  "bab_nomor": "II",                 # opsional, default "II"
  "bab_judul": "TINJAUAN PUSTAKA",   # opsional, default "TINJAUAN PUSTAKA"
  "subbab": [
    {
      "nomor": "2.1",
      "judul": "Ketoasidosis Diabetikum",
      "paragraf": ["...", "..."],          # opsional
      "tabel": { ... },                    # opsional (lihat render_tabel)
      "gambar": [ {"caption": "...", "sumber": "..."} ],   # opsional
      "anak_subbab": [                      # opsional (1-2 level)
        {
          "nomor": "2.1.1",
          "judul": "Definisi dan epidemiologi",
          "paragraf": ["..."],
          "tabel": { ... },
          "gambar": [ ... ],
          "anak_subbab": [ {"nomor": "2.1.1.1", "judul": "...", "paragraf": [...]} ]
        }
      ]
    }
  ],
  "referensi": ["Entri APA 7 dengan *nama jurnal* miring.", "..."]
}

Skema "tabel":
{
  "nomor": "2.1",                     # menghasilkan "Tabel 2.1."
  "judul": "Perbandingan ...",        # sentence case, tanpa titik akhir
  "header": ["Kolom 1", "Kolom 2"],
  "baris": [ ["sel a", "sel b"], ["sel c", "sel d"] ],
  "sumber": "Disusun dari Penulis (Tahun), ..."   # opsional tetapi disarankan
}
Markup *miring* berlaku di header, sel, dan judul/sumber tabel.
"""

import sys
import json
import re

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Times New Roman"
SIZE = 12
INDENT = Cm(1.27)        # ~7 ketukan
LIST_INDENT = Cm(0.9)    # indentasi kiri daftar bernomor


# ---------- util italic markup ----------
def add_runs(paragraph, text, *, italic_all=False, bold_all=False, size=SIZE):
    """Tambahkan teks ke paragraf, merender penggalan *...* sebagai italic."""
    if text is None:
        text = ""
    parts = re.split(r"(\*[^*]+\*)", str(text))
    for part in parts:
        if part == "":
            continue
        if len(part) >= 2 and part.startswith("*") and part.endswith("*"):
            run = paragraph.add_run(part[1:-1])
            run.italic = True
        else:
            run = paragraph.add_run(part)
            run.italic = italic_all
        if bold_all:
            run.bold = True
        run.font.name = FONT
        run.font.size = Pt(size)
        _set_run_font(run, FONT)
    return paragraph


def _set_run_font(run, font_name):
    """Pastikan font berlaku untuk ascii, hAnsi, dan cs."""
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(attr), font_name)


# ---------- paragraf helpers ----------
def body_paragraph(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.first_line_indent = INDENT
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


def plain_paragraph(doc, text):
    """Paragraf justify tanpa indentasi baris pertama (mis. kalimat pengantar tabel)."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


def numbered_item(doc, n, text):
    """Item daftar bernomor manual dengan hanging indent (angka, bukan bullet)."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.left_indent = LIST_INDENT + Cm(0.7)
    pf.first_line_indent = -Cm(0.7)
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    lead = p.add_run(f"{n}.\t")
    lead.font.name = FONT
    lead.font.size = Pt(SIZE)
    _set_run_font(lead, FONT)
    add_runs(p, text)
    return p


def subbab(doc, nomor, judul, space_before=12):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_before = Pt(space_before)
    pf.space_after = Pt(0)
    add_runs(p, f"{nomor}\t{judul}", bold_all=True)
    return p


def anak_subbab(doc, nomor, judul):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_before = Pt(6)
    pf.space_after = Pt(0)
    add_runs(p, f"{nomor}\t{judul}", bold_all=True)
    return p


def anak_anak_subbab(doc, nomor, judul):
    """Anak-anak subbab (2.x.y.z): rata kiri, tidak tebal."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_before = Pt(6)
    pf.space_after = Pt(0)
    add_runs(p, f"{nomor}\t{judul}", bold_all=False)
    return p


def chapter_heading(doc, line1, line2):
    for i, line in enumerate((line1, line2)):
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
        pf.line_spacing = 1.5
        pf.space_before = Pt(28) if i == 0 else Pt(0)  # ~1 cm di bawah margin atas
        pf.space_after = Pt(18) if i == 1 else Pt(0)
        run = p.add_run(line.upper())
        run.bold = True
        run.font.name = FONT
        run.font.size = Pt(SIZE)
        _set_run_font(run, FONT)


def reference_entry(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    pf.left_indent = Cm(1.27)
    pf.first_line_indent = -Cm(1.27)  # hanging indent APA
    pf.space_after = Pt(6)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


# ---------- TABEL (gaya UNUD: tiga garis horizontal, tanpa garis vertikal) ----------
def _set_cell_text(cell, text, *, bold=False, align=WD_ALIGN_PARAGRAPH.LEFT, size=10):
    cell.text = ""
    p = cell.paragraphs[0]
    pf = p.paragraph_format
    pf.alignment = align
    pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    add_runs(p, text, bold_all=bold, size=size)


def _clear_all_borders(table):
    """Hapus seluruh border tabel (akan ditambahkan hanya yang horizontal)."""
    tbl = table._tbl
    tblPr = tbl.tblPr
    # buang tblBorders lama bila ada
    for old in tblPr.findall(qn("w:tblBorders")):
        tblPr.remove(old)
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "none")
        el.set(qn("w:sz"), "0")
        el.set(qn("w:space"), "0")
        borders.append(el)
    tblPr.append(borders)


def _set_row_border(row, position, *, sz=8):
    """Pasang garis horizontal (top/bottom) pada seluruh sel di satu baris."""
    for cell in row.cells:
        tcPr = cell._tc.get_or_add_tcPr()
        tcBorders = tcPr.find(qn("w:tcBorders"))
        if tcBorders is None:
            tcBorders = OxmlElement("w:tcBorders")
            tcPr.append(tcBorders)
        existing = tcBorders.find(qn(f"w:{position}"))
        if existing is not None:
            tcBorders.remove(existing)
        el = OxmlElement(f"w:{position}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), "000000")
        tcBorders.append(el)


def render_tabel(doc, t):
    """Render satu tabel sesuai aturan UNUD (Pedoman hlm. 21)."""
    nomor = t.get("nomor", "")
    judul = t.get("judul", "")
    header = t.get("header", [])
    baris = t.get("baris", [])
    sumber = t.get("sumber", "")

    # Judul tabel: simetris (center) DI ATAS tabel, spasi 1, tanpa titik akhir.
    cap = doc.add_paragraph()
    pf = cap.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    pf.space_before = Pt(12)
    pf.space_after = Pt(6)  # ~jarak ke tabel
    label = f"Tabel {nomor}. " if nomor else "Tabel. "
    add_runs(cap, label + judul)

    if not header:
        return

    n_cols = len(header)
    table = doc.add_table(rows=1, cols=n_cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    _clear_all_borders(table)

    # header
    hdr = table.rows[0]
    for j, htext in enumerate(header):
        _set_cell_text(hdr.cells[j], htext, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)

    # body
    for r in baris:
        cells = table.add_row().cells
        for j in range(n_cols):
            val = r[j] if j < len(r) else ""
            _set_cell_text(cells[j], val, bold=False, align=WD_ALIGN_PARAGRAPH.LEFT)

    # Tiga garis horizontal: atas kepala, bawah kepala, bawah tabel
    _set_row_border(table.rows[0], "top")
    _set_row_border(table.rows[0], "bottom")
    _set_row_border(table.rows[-1], "bottom")

    # Baris "Sumber:" di bawah tabel (spasi 1)
    if sumber:
        src = doc.add_paragraph()
        pf = src.paragraph_format
        pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
        pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
        pf.space_before = Pt(4)
        pf.space_after = Pt(6)
        add_runs(src, "Sumber: " + sumber, size=10)


# ---------- GAMBAR (caption di bawah; penanda tempat gambar) ----------
def render_gambar(doc, g):
    """Sisipkan penanda tempat gambar + caption simetris di bawahnya (spasi 1)."""
    nomor = g.get("nomor", "")
    caption = g.get("caption", "")
    sumber = g.get("sumber", "")

    # penanda tempat (placeholder) — diganti gambar asli oleh penulis
    ph = doc.add_paragraph()
    pf = ph.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf.space_before = Pt(8)
    pf.space_after = Pt(4)
    run = ph.add_run(f"[Sisipkan Gambar {nomor} di sini]")
    run.italic = True
    run.font.name = FONT
    run.font.size = Pt(SIZE)
    _set_run_font(run, FONT)

    cap = doc.add_paragraph()
    cf = cap.paragraph_format
    cf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    cf.space_after = Pt(8)
    label = f"Gambar {nomor}. " if nomor else "Gambar. "
    teks = label + caption
    if sumber:
        teks = teks.rstrip() + f" ({sumber})"
    add_runs(cap, teks)


# ---------- render blok konten (paragraf, tabel, gambar) ----------
def render_konten(doc, node):
    # Mode terurut: bila ada "konten" (daftar blok bertipe), render persis urutannya.
    # Berguna saat tabel/gambar harus berada DI ANTARA paragraf.
    blok = node.get("konten")
    if blok:
        for b in blok:
            tipe = b.get("tipe")
            if tipe == "paragraf":
                body_paragraph(doc, b.get("teks", ""))
            elif tipe == "tabel":
                render_tabel(doc, b)
            elif tipe == "gambar":
                render_gambar(doc, b)
        return
    # Mode sederhana: paragraf -> tabel -> gambar.
    for para in node.get("paragraf", []) or []:
        body_paragraph(doc, para)
    # tabel: bisa satu objek atau list
    tabel = node.get("tabel")
    if tabel:
        if isinstance(tabel, list):
            for t in tabel:
                render_tabel(doc, t)
        else:
            render_tabel(doc, tabel)
    # gambar: list caption
    for g in node.get("gambar", []) or []:
        render_gambar(doc, g)


def render_subbab(doc, node, level=2, first=False):
    """Render subbab/anak-subbab secara rekursif (maks 4 level: 2.x.y.z)."""
    nomor = node.get("nomor", "")
    judul = node.get("judul", "")
    if level == 2:
        subbab(doc, nomor, judul, space_before=0 if first else 12)
    elif level == 3:
        anak_subbab(doc, nomor, judul)
    else:
        anak_anak_subbab(doc, nomor, judul)

    render_konten(doc, node)

    for child in node.get("anak_subbab", []) or []:
        render_subbab(doc, child, level=level + 1, first=False)


# ---------- page setup & footer ----------
def setup_page(doc):
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.left_margin = Cm(4.0)
    sec.right_margin = Cm(3.0)
    sec.top_margin = Cm(3.0)
    sec.bottom_margin = Cm(3.0)

    style = doc.styles["Normal"]
    style.font.name = FONT
    style.font.size = Pt(SIZE)
    style.font.color.rgb = RGBColor(0, 0, 0)
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(attr), FONT)

    settings = doc.settings.element
    zoom = settings.find(qn("w:zoom"))
    if zoom is not None and zoom.get(qn("w:percent")) is None:
        zoom.set(qn("w:percent"), "100")


def add_centered_page_number(doc):
    footer = doc.sections[0].footer
    footer.is_linked_to_previous = False
    p = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    def field(instr):
        run = p.add_run()
        fld_begin = OxmlElement("w:fldChar"); fld_begin.set(qn("w:fldCharType"), "begin")
        instr_el = OxmlElement("w:instrText"); instr_el.set(qn("xml:space"), "preserve"); instr_el.text = instr
        fld_end = OxmlElement("w:fldChar"); fld_end.set(qn("w:fldCharType"), "end")
        run._r.append(fld_begin); run._r.append(instr_el); run._r.append(fld_end)
        run.font.name = FONT; run.font.size = Pt(SIZE); _set_run_font(run, FONT)

    field("PAGE")


# ---------- validasi ringan ----------
def validate(data):
    warn = sys.stderr.write
    subs = data.get("subbab", [])
    if not subs:
        warn("PERINGATAN: tidak ada 'subbab' yang diisi.\n")
    # cek penomoran terurut di tingkat 2.x
    nums = [s.get("nomor", "") for s in subs]
    for n in nums:
        if not re.match(r"^\d+\.\d+$", n or ""):
            warn(f"PERINGATAN: nomor subbab '{n}' tidak berformat 'X.Y'.\n")

    def count_tables(node):
        c = 0
        t = node.get("tabel")
        if t:
            c += len(t) if isinstance(t, list) else 1
        for b in node.get("konten", []) or []:
            if b.get("tipe") == "tabel":
                c += 1
        for child in node.get("anak_subbab", []) or []:
            c += count_tables(child)
        return c

    total_tabel = sum(count_tables(s) for s in subs)
    if total_tabel == 0:
        warn("CATATAN: belum ada tabel. Cetak biru menyarankan minimal 1 tabel "
             "sintesis pada subbab perbandingan luaran.\n")

    # cek setiap entri referensi muncul minimal sekali (berdasarkan nama+tahun pertama)
    def all_text(node, acc):
        for p in node.get("paragraf", []) or []:
            acc.append(p)
        t = node.get("tabel")
        if t:
            for tt in (t if isinstance(t, list) else [t]):
                acc.append(json.dumps(tt, ensure_ascii=False))
        for g in node.get("gambar", []) or []:
            acc.append(json.dumps(g, ensure_ascii=False))
        for b in node.get("konten", []) or []:
            acc.append(json.dumps(b, ensure_ascii=False))
        for child in node.get("anak_subbab", []) or []:
            all_text(child, acc)
        return acc

    body_blob = " ".join(sum((all_text(s, []) for s in subs), []))
    for entry in data.get("referensi", []) or []:
        m = re.match(r"^([A-Za-zÀ-ÿ'’\-]+)", entry.strip())
        surname = m.group(1) if m else ""
        if surname and surname not in body_blob:
            warn(f"CATATAN: '{surname}' ada di Daftar Referensi tetapi tampaknya "
                 f"tidak dikutip di teks.\n")


# ---------- main ----------
def build(data, out_path):
    validate(data)

    doc = Document()
    setup_page(doc)
    add_centered_page_number(doc)

    bab_nomor = data.get("bab_nomor", "II")
    bab_judul = data.get("bab_judul", "TINJAUAN PUSTAKA")
    chapter_heading(doc, f"BAB {bab_nomor}", bab_judul)

    subs = data.get("subbab", [])
    for i, s in enumerate(subs):
        render_subbab(doc, s, level=2, first=(i == 0))

    # Daftar Referensi (alat bantu, bukan bagian formal bab)
    refs = data.get("referensi", [])
    if refs:
        subbab(doc, "", "Daftar Referensi (BAB II)")
        note = plain_paragraph(
            doc,
            "Daftar kerja sumber yang dikutip pada BAB II (APA 7) untuk memudahkan "
            "penyusunan Daftar Pustaka akhir; bukan bagian formal bab.",
        )
        for r in note.runs:
            r.italic = True
        for entry in sorted(refs, key=lambda s: s.lower()):
            reference_entry(doc, entry)

    doc.save(out_path)

    def count_paragraf(node):
        c = len(node.get("paragraf", []) or [])
        c += sum(1 for b in node.get("konten", []) or [] if b.get("tipe") == "paragraf")
        for child in node.get("anak_subbab", []) or []:
            c += count_paragraf(child)
        return c

    total_para = sum(count_paragraf(s) for s in subs)
    print(f"Tersimpan: {out_path}")
    print(f"Jumlah subbab tingkat 2: {len(subs)}")
    print(f"Total paragraf isi: {total_para}")
    print(f"Jumlah referensi: {len(refs)}")


def main():
    if len(sys.argv) != 3:
        sys.stderr.write("Pemakaian: python build_bab2.py <input.json> <output.docx>\n")
        sys.exit(1)
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    build(data, sys.argv[2])


if __name__ == "__main__":
    main()
