# Tanda-tanda tulisan AI — dan cara menghindarinya (BAB I)

Acuan ringkas untuk memastikan Latar Belakang **tidak terbaca seperti keluaran model bahasa**. Disarikan dan diadaptasi dari esai *Wikipedia: Signs of AI writing* ke konteks usulan penelitian anestesi/ICU berbahasa Indonesia. **Baca sekali sebelum menulis**, lalu pakai checklist di akhir sebagai uji-mandiri sebelum render.

> **Peringatan penting (jangan jadi pemburu kata kunci).** Tidak ada satu kata pun yang otomatis "haram". Tujuannya **bukan** menghapus daftar kata, melainkan menulis prosa yang **spesifik, berangka, dan bersitasi** sehingga tanda-tanda ini hilang dengan sendirinya. Satu-dua frasa di bawah bisa muncul wajar; yang menjadi tanda AI adalah **kepadatannya** — banyak pola berulang dalam satu paragraf. Dalam tulisan ilmiah, sebagian kata (mis. "signifikan" dalam arti statistik, "robust" untuk metode) sah dipakai pada tempatnya — yang dilarang adalah pemakaian dekoratif tanpa isi.

---

## A. Tanda pada ISI (content)

**A1. Penekanan berlebihan pada signifikansi/peran.**
Model bahasa gemar menyatakan bahwa sesuatu "penting", "berperan vital", atau "menjadi tonggak", tanpa membuktikannya. Penguji konsultan justru menilai dari fakta, bukan dari kata sifat.
- Buruk: "Manajemen nyeri memegang peranan yang sangat penting dan menjadi tonggak dalam keberhasilan pembedahan modern."
- Baik: "Nyeri sedang–berat masih dijumpai pada 24 jam pertama pascaoperasi meski prosedur minimal invasif (Batchelor et al., 2019)."

**A2. Bahasa promosi / puffery.**
Frasa beriklan ("sangat menjanjikan", "terobosan", "revolusioner", "canggih", "tak tertandingi") tidak punya tempat di latar belakang ilmiah. Ganti dengan klaim yang bisa diuji + sitasi.

**A3. Atribusi samar & overgeneralisasi opini.** *(paling merusak di bab berbasis sitasi)*
"Beberapa studi menunjukkan", "para ahli sepakat", "penelitian membuktikan", "telah diketahui secara luas" — tanpa menyebut siapa dan tahun berapa. Ini sekaligus **tanda AI dan pelanggaran kaidah sitasi**. Setiap klaim empirik harus menempel pada `(Penulis, Tahun)` yang nyata.
- Buruk: "Beberapa penelitian menunjukkan blok fasia lebih unggul."
- Baik: "Blok ESP menurunkan skor nyeri 24 jam dibanding kontrol pada reseksi paru (Forero et al., 2016; Finnerty et al., 2020)."

**A4. Analisis dangkal.**
Kalimat yang terdengar berisi tetapi hanya menyatakan ulang hal yang sudah jelas ("Hal ini menunjukkan bahwa nyeri perlu ditangani dengan baik"). Setiap kalimat harus memajukan argumen menuju gap, bukan mengisi ruang.

**A5. Penutup formulaik "tantangan & prospek masa depan".**
Pola "Meski demikian, masih terdapat berbagai tantangan ... ke depannya diharapkan ...". Paragraf 8 menutup dengan **tujuan + relevansi konkret**, bukan harapan umum.

---

## B. Tanda pada BAHASA & TATA KALIMAT

**B1. Densitas tinggi "kosakata-AI".**
Kata/frasa yang melonjak frekuensinya pada teks pasca-2022 dan sering muncul berbarengan. Padanan Indonesia yang patut diwaspadai (pakai hemat, jangan menumpuk):

> *lanskap* (sebagai metafora), *menggarisbawahi*, *menyoroti*, *menjadi bukti / testament*, *tak terbantahkan / tidak dapat dipungkiri*, *memainkan peran (penting/krusial/vital/pivotal)*, *secara signifikan* (di luar makna statistik), *komprehensif*, *holistik*, *mendalam*, *rumit/kompleks nan*, *kaya akan*, *beragam / berbagai macam*, *di era modern ini*, *seiring perkembangan zaman*, *di tengah*, *pada akhirnya*, *yang patut dicatat*, *menjembatani kesenjangan*, *membuka jalan bagi*, *meningkatkan (enhance)*, *mengoptimalkan*, *mumpuni*, *tonggak / babak baru*.

**B2. Paralelisme negatif.**
Konstruksi "**bukan hanya … tetapi juga …**" dan "**bukan … melainkan …**" yang dipakai untuk efek retoris. Sesekali boleh; berulang = tanda AI. Ubah jadi pernyataan langsung.
- Buruk: "Blok ini bukan hanya efektif, tetapi juga aman dan mudah dipelajari."
- Baik: "Blok ini menurunkan kebutuhan opioid 24 jam dan memiliki insidensi komplikasi <1% (Penulis, Tahun)."

**B3. Pola tiga-serangkai (*rule of three*).**
Daftar tiga sifat/contoh yang dipaksakan ("aman, efektif, dan ekonomis"; "cepat, tepat, dan akurat"). Jika tiga unsur tidak semuanya bermakna, sebut satu yang penting dengan datanya.

**B4. Variasi elegan (*elegant variation*) — khusus berbahaya di tulisan ilmiah.**
Mengganti-ganti sinonim untuk istilah teknis yang seharusnya **konsisten**, demi "menghindari pengulangan". Sekali "*strong ion difference* (SID)", seterusnya "SID" — jangan berselang-seling "selisih ion kuat / parameter ionik / nilai ion". Istilah klinis tetap satu sebutan.

**B5. Penghindaran kopula sederhana / over-nominalisasi.**
Membungkus gagasan sederhana dalam frasa benda yang berat ("melakukan pelaksanaan terhadap pemberian" alih-alih "memberikan"). Pilih kata kerja langsung; pasif baku tetap boleh.

---

## C. Tanda pada GAYA, TRANSISI & MARKUP

**C1. Penjejalan transisi.**
"Selain itu", "Lebih lanjut", "Selanjutnya", "Di sisi lain" di **tiap** awal kalimat/paragraf. Pakai penghubung hanya saat memang ada hubungan sebab-akibat atau pertentangan.

**C2. Editorializing / hedging klise.**
"Penting untuk dicatat bahwa", "perlu digarisbawahi", "patut dicatat", "menariknya", "tidak dapat dipungkiri". Hapus — langsung sampaikan faktanya.

**C3. Ritme kalimat seragam.**
Semua kalimat panjang-sedang dengan pola sama. Selang-seling kalimat kompleks dengan kalimat pendek yang tegas.

**C4. Markup yang tak diminta (karena skrip yang merender format).**
Jangan menaruh **boldface**, *Title Case* pada judul Indonesia, tanda hubung "em dash" (—) dekoratif, kutip melengkung, atau emoji di dalam teks JSON. Penekanan miring hanya untuk istilah asing lewat `*asterisk*`. Penomoran ditangani skrip — jangan menomori manual.

---

## Checklist uji-mandiri (jalankan sebelum render)

1. Paragraf 1 benar-benar tanpa angka & tanpa sitasi, tetapi tetap konkret (bukan klise pembuka)?
2. Setiap klaim empirik punya `(Penulis, Tahun)` nyata — tidak ada "beberapa studi/para ahli" tanpa nama?
3. Tidak ada frasa B1 yang menumpuk (maks sesekali, selalu berisi)?
4. Tidak ada "bukan hanya … tetapi juga …" atau tiga-serangkai yang dipaksakan?
5. Istilah teknis konsisten dari awal sampai akhir (tanpa variasi sinonim)?
6. Tidak ada "penting untuk dicatat / tidak dapat dipungkiri / seiring perkembangan zaman / di era modern ini"?
7. Tidak ada penutup "tantangan & prospek masa depan" yang formulaik?
8. Ritme kalimat bervariasi; transisi hanya saat perlu?
9. Angka selalu spesifik dan bersatuan (bukan "banyak/tinggi/cukup")?
10. Bandingkan kepadatan dengan `contoh_anotasi.md` — apakah sepadat itu, tanpa kalimat pengisi?

Bila satu butir gagal, perbaiki **isinya** (tambah angka/sitasi nyata, buang frasa kosong), bukan sekadar mengganti kata.
