# Cek kelayakan blinding (penyamaran) — hanya pertimbangan, BUKAN isi BAB I

Berdasarkan Karanicolas, Farrokhyar & Bhandari (2010), *Blinding: Who, what, when, why, how?* Gunakan ini saat intake untuk menilai apakah studi user **bisa dan sebaiknya** disamarkan, lalu sampaikan kesimpulan **sebagai catatan singkat di chat**. Jangan tulis pembahasan blinding di dalam Latar Belakang/Rumusan/Tujuan/Manfaat.

## 5 kelompok yang idealnya dibutakan
1. **Peserta/pasien** — pengetahuan alokasi memengaruhi perilaku & laporan luaran subjektif.
2. **Klinisi/operator** — mencegah perbedaan perlakuan antar kelompok.
3. **Pengumpul data**
4. **Penilai luaran (*outcome adjudicator*)** — kritis untuk luaran subjektif maupun "objektif" yang tetap butuh penilaian.
5. **Analis data** — cegah bias pemilihan/pelaporan uji statistik.

> Blinding bukan all-or-nothing. Sebutkan secara eksplisit siapa yang dibutakan, caranya, dan (idealnya) apakah keberhasilannya diuji.

## Bila operator tak bisa dibutakan (umum pada studi prosedural/blok/bedah)
Teknik praktis: jangan memberi tahu pasien alokasinya (blok dilakukan setelah induksi); samarkan **penilai luaran** (assessor-blinded, mis. Tim APS); seragamkan tampilan luka/dressing; pakai amplop alokasi tersegel bernomor (*allocation concealment* ≠ blinding).

## Bila penyamaran benar-benar mustahil
- Standardisasi perlakuan kedua kelompok (selain intervensi).
- Pertimbangkan desain *expertise-based*.
- Pakai luaran objektif & andal; pertimbangkan penilaian duplikat.
- **Akui keterbatasannya** secara terbuka (di Metode/Keterbatasan, bukan di BAB I).

## Output yang diharapkan dari skill (di chat saja)
Satu paragraf ringkas, mis.:
> "Studi intervensi ini layak dirancang *double-blind*: pasien dibutakan karena blok/intervensi diberikan setelah induksi, dan penilai luaran (Tim APS) dibutakan terhadap alokasi. Operator tidak dapat dibutakan karena teknik tampak berbeda — ini perlu diakui sebagai keterbatasan di bab Metode. Pertimbangkan *allocation concealment* via amplop tersegel bernomor."
