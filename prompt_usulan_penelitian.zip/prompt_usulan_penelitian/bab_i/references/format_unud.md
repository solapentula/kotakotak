# Aturan format & bahasa — Panduan UNUD 2024 (intisari untuk BAB I)

Skrip `build_bab1.py` sudah menegakkan sebagian besar ini. Acuan bila perlu memeriksa detail.

## Naskah & halaman
- Kertas A4 (21 × 29,7 cm), HVS 80 g/m², putih, tidak bolak-balik.
- Margin: **kiri 4 cm**, **atas 3 cm**, **bawah 3 cm**, **kanan 3 cm**.
- Nomor halaman bagian inti: angka Arab di sudut kanan atas; **kecuali halaman bab** → di tengah bawah. (Skrip memakai tengah-bawah karena BAB I diawali halaman bab.)

## Huruf, spasi, paragraf
- Times New Roman **12 pt** seluruh naskah.
- Spasi **1,5** untuk isi. Spasi **1** untuk daftar pustaka/abstrak/daftar-daftar dan judul tabel/gambar.
- Indentasi baris pertama paragraf mulai **ketukan ke-7** dari tepi kiri (≈1,27 cm).
- Bahasa Indonesia baku; **kalimat pasif**, tanpa orang pertama/kedua ("saya/kami/kita/Anda").
- Istilah asing/daerah dicetak **miring** (*italic*).

## Bilangan & satuan
- Bilangan < 10 atau di awal kalimat ditulis dengan huruf; selebihnya angka.
- Desimal pakai **koma** (mis. 29,7%), bukan titik.
- Satuan tanpa titik (m, mg, kg, mL).

## Judul bab & subbab
- **Judul bab**: halaman baru, KAPITAL semua, tebal, simetris, ~4 cm dari tepi atas, tanpa titik. Nomor bab angka Romawi (BAB I).
- **Subbab** (1.1, 1.2, …): mulai tepi kiri, tebal, tanpa titik di akhir; kapital di tiap kata kecuali kata sambung/depan.
- **Anak subbab** (1.3.1, …): tepi kiri, tebal; huruf pertama tiap kata leksikal kapital. (Contoh referensi memakai sentence case "Tujuan umum"; skrip mengikuti teks yang Anda kirim.)

## Perincian ke bawah
- Pakai **nomor/huruf** (1., 2., a., b.). **Dilarang** memakai tanda hubung (-) atau bullet.

## Sumber & sitasi
- Gaya: **APA edisi ke-7** (in-text identik dengan Harvard).
- In-text: nama akhir saja; 2 penulis sebut keduanya; >2 penulis → penulis pertama + `et al.`/`dkk.`. Tahun dalam kurung. Sumber jamak diurut lama→baru.
- Rujukan **≤10 tahun terakhir**, diutamakan jurnal terakreditasi/internasional. Pengutipan dari kutipan maksimal sekali.
- Letakkan rujukan sedekat mungkin dengan materi yang disitir.

## Daftar pustaka (APA 7) — untuk daftar referensi alat bantu
- Urut alfabetis nama akhir; hanging indent; nama jurnal & volume dicetak miring; sertakan DOI bila ada.
- Contoh artikel jurnal:
  Stark, P. A., Myles, P. S., & Burke, J. A. (2013). Development and psychometric evaluation of a postoperative quality of recovery score. *Anesthesiology*, *118*(6), 1332–1340. https://doi.org/10.1097/ALN.0b013e318289b84b
