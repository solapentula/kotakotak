#!/usr/bin/env python3
"""
build_bab1.py — Render BAB I PENDAHULUAN (usulan penelitian) ke .docx
sesuai Panduan Penulisan Pascasarjana Universitas Udayana 2024.

Pemakaian:
    python scripts/build_bab1.py <input.json> <output.docx>

Format yang ditegakkan otomatis:
- Kertas A4, margin kiri 4 cm / atas-bawah-kanan 3 cm
- Times New Roman 12 pt, spasi 1,5 (isi); daftar referensi 1 spasi, hanging indent
- Heading "BAB I" + "PENDAHULUAN" kapital, tebal, simetris di awal halaman
- Subbab (1.1 dst.) rata kiri, tebal; anak subbab (1.3.1 dst.) tebal
- Paragraf isi rata kanan-kiri (justify), indentasi baris pertama
- Istilah yang ditandai *miring* dirender italic
- Penomoran daftar otomatis (bukan bullet/dash, sesuai pedoman)
"""

import sys
import json
import re

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Times New Roman"
SIZE = 12
INDENT = Cm(1.27)        # ~7 ketukan
LIST_INDENT = Cm(0.9)    # indentasi kiri daftar bernomor


# ---------- util italic markup ----------
def add_runs(paragraph, text, *, italic_all=False, bold_all=False):
    """Tambahkan teks ke paragraf, merender penggalan *...* sebagai italic."""
    if text is None:
        text = ""
    parts = re.split(r"(\*[^*]+\*)", text)
    for part in parts:
        if part == "":
            continue
        if len(part) >= 2 and part.startswith("*") and part.endswith("*"):
            run = paragraph.add_run(part[1:-1])
            run.italic = True
        else:
            run = paragraph.add_run(part)
            run.italic = italic_all
        if bold_all:
            run.bold = True
        run.font.name = FONT
        run.font.size = Pt(SIZE)
        _set_run_font(run, FONT)
    return paragraph


def _set_run_font(run, font_name):
    """Pastikan font berlaku untuk ascii, hAnsi, dan cs."""
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(attr), font_name)


# ---------- paragraf helpers ----------
def body_paragraph(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.first_line_indent = INDENT
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


def plain_paragraph(doc, text):
    """Paragraf rata kiri tanpa indentasi (mis. kalimat pengantar)."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


def numbered_item(doc, n, text):
    """Item daftar bernomor manual dengan hanging indent."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.left_indent = LIST_INDENT + Cm(0.7)
    pf.first_line_indent = -Cm(0.7)  # hanging
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    lead = p.add_run(f"{n}.\t")
    lead.font.name = FONT
    lead.font.size = Pt(SIZE)
    _set_run_font(lead, FONT)
    add_runs(p, text)
    return p


def subbab(doc, text, space_before=12):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_before = Pt(space_before)
    pf.space_after = Pt(0)
    add_runs(p, text, bold_all=True)
    return p


def anak_subbab(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_before = Pt(6)
    pf.space_after = Pt(0)
    add_runs(p, text, bold_all=True)
    return p


def chapter_heading(doc, line1, line2):
    for i, line in enumerate((line1, line2)):
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
        pf.line_spacing = 1.5
        pf.space_before = Pt(28) if i == 0 else Pt(0)  # ~1 cm di bawah margin atas
        pf.space_after = Pt(18) if i == 1 else Pt(0)
        run = p.add_run(line.upper())
        run.bold = True
        run.font.name = FONT
        run.font.size = Pt(SIZE)
        _set_run_font(run, FONT)


def reference_entry(doc, text):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    pf.left_indent = Cm(1.27)
    pf.first_line_indent = -Cm(1.27)  # hanging indent APA
    pf.space_after = Pt(6)
    pf.space_before = Pt(0)
    add_runs(p, text)
    return p


# ---------- page setup & footer ----------
def setup_page(doc):
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.left_margin = Cm(4.0)
    sec.right_margin = Cm(3.0)
    sec.top_margin = Cm(3.0)
    sec.bottom_margin = Cm(3.0)

    # default style
    style = doc.styles["Normal"]
    style.font.name = FONT
    style.font.size = Pt(SIZE)
    style.font.color.rgb = RGBColor(0, 0, 0)
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(attr), FONT)

    # Rapikan settings.xml: <w:zoom> bawaan python-docx kadang tanpa atribut
    # w:percent sehingga gagal validasi skema. Pastikan ada atau hapus elemennya.
    settings = doc.settings.element
    zoom = settings.find(qn("w:zoom"))
    if zoom is not None and zoom.get(qn("w:percent")) is None:
        zoom.set(qn("w:percent"), "100")


def add_centered_page_number(doc):
    """Nomor halaman di tengah bawah (sesuai aturan halaman bab)."""
    footer = doc.sections[0].footer
    footer.is_linked_to_previous = False
    p = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    def field(instr):
        run = p.add_run()
        fld_begin = OxmlElement("w:fldChar"); fld_begin.set(qn("w:fldCharType"), "begin")
        instr_el = OxmlElement("w:instrText"); instr_el.set(qn("xml:space"), "preserve"); instr_el.text = instr
        fld_end = OxmlElement("w:fldChar"); fld_end.set(qn("w:fldCharType"), "end")
        run._r.append(fld_begin); run._r.append(instr_el); run._r.append(fld_end)
        run.font.name = FONT; run.font.size = Pt(SIZE); _set_run_font(run, FONT)

    field("PAGE")


# ---------- main ----------
def build(data, out_path):
    doc = Document()
    setup_page(doc)
    add_centered_page_number(doc)

    chapter_heading(doc, "BAB I", "PENDAHULUAN")

    # 1.1 Latar Belakang
    subbab(doc, "1.1\tLatar Belakang", space_before=0)
    lb = data.get("latar_belakang", [])
    if len(lb) != 8:
        sys.stderr.write(
            f"PERINGATAN: latar_belakang berisi {len(lb)} paragraf (seharusnya 8).\n"
        )
    if lb and re.search(r"\([^)]*\b(19|20)\d{2}\b[^)]*\)", lb[0]):
        sys.stderr.write(
            "PERINGATAN: paragraf 1 tampaknya mengandung sitasi; seharusnya tanpa sitasi.\n"
        )
    for para in lb:
        body_paragraph(doc, para)

    # 1.2 Rumusan Masalah
    subbab(doc, "1.2\tRumusan Masalah")
    if data.get("rumusan_pengantar"):
        plain_paragraph(doc, data["rumusan_pengantar"])
    for i, q in enumerate(data.get("rumusan_masalah", []), 1):
        numbered_item(doc, i, q)

    # 1.3 Tujuan Penelitian
    subbab(doc, "1.3\tTujuan Penelitian")
    anak_subbab(doc, "1.3.1\tTujuan umum")
    if data.get("tujuan_umum"):
        body_paragraph(doc, data["tujuan_umum"])
    anak_subbab(doc, "1.3.2\tTujuan khusus")
    for i, t in enumerate(data.get("tujuan_khusus", []), 1):
        numbered_item(doc, i, t)

    # 1.4 Manfaat Penelitian
    subbab(doc, "1.4\tManfaat Penelitian")
    anak_subbab(doc, "1.4.1\tManfaat teoritis")
    for i, m in enumerate(data.get("manfaat_teoritis", []), 1):
        numbered_item(doc, i, m)
    anak_subbab(doc, "1.4.2\tManfaat praktis")
    for i, m in enumerate(data.get("manfaat_praktis", []), 1):
        numbered_item(doc, i, m)

    # Daftar Referensi (alat bantu)
    refs = data.get("referensi", [])
    if refs:
        subbab(doc, "Daftar Referensi (BAB I)")
        note = plain_paragraph(
            doc,
            "Daftar kerja sumber yang dikutip pada BAB I (APA 7) untuk memudahkan "
            "penyusunan Daftar Pustaka akhir; bukan bagian formal bab.",
        )
        for r in note.runs:
            r.italic = True
        for entry in sorted(refs, key=lambda s: s.lower()):
            reference_entry(doc, entry)

    doc.save(out_path)
    print(f"Tersimpan: {out_path}")
    print(f"Jumlah paragraf Latar Belakang: {len(lb)}")
    print(f"Jumlah rumusan masalah: {len(data.get('rumusan_masalah', []))}")
    print(f"Jumlah referensi: {len(refs)}")


def main():
    if len(sys.argv) != 3:
        sys.stderr.write("Pemakaian: python build_bab1.py <input.json> <output.docx>\n")
        sys.exit(1)
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    build(data, sys.argv[2])


if __name__ == "__main__":
    main()
