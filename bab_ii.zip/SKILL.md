---
name: babtinjauanpustaka
description: "Menyusun BAB II TINJAUAN PUSTAKA usulan penelitian (landasan teoritis + tinjauan hasil penelitian terkait) sesuai Panduan Penulisan Pascasarjana Universitas Udayana 2024, untuk residen Anestesiologi & Terapi Intensif. WAJIB pakai skill ini setiap kali user mengetik `/babtinjauan` atau `/babdua`, ATAU meminta dibuatkan/diperbaiki Tinjauan Pustaka, BAB 2, kajian teori, atau bab tinjauan literatur usulan penelitian/tesis/proposal di bidang anestesi, ICU, perioperatif, hemodinamik, nyeri, sepsis, syok, atau terapi intensif. Juga gunakan ketika user sudah punya judul/PICO matang atau BAB I selesai (mis. keluaran dari /usulanpenelitian atau /babpendahuluan) dan ingin diteruskan ke penulisan BAB II dalam format docx. Output utamanya adalah file .docx siap-pakai sesuai kaidah UNUD (subbab tematik bernomor, tabel sintesis tiga-garis, sitasi APA 7), bukan jawaban di chat."
license: Proprietary
---

# Penyusun BAB II TINJAUAN PUSTAKA — Usulan Penelitian UNUD 2024

## Apa yang dihasilkan skill ini

Sebuah file **.docx** berisi BAB II TINJAUAN PUSTAKA yang lolos pembacaan penguji (Spesialis Anestesiologi & Terapi Intensif Konsultan): rangkaian **subbab tematik bernomor 2.1–2.7** yang membangun landasan teori dari komponen PICO, memuncak pada **tabel sintesis bukti** yang mengadu intervensi dengan komparator, lalu menutup dengan celah dan keamanan. Ditambah **Daftar Referensi BAB II** (APA 7) di akhir sebagai alat bantu kompilasi, bukan bagian formal bab.

Formatting (A4, Times New Roman 12, spasi 1,5, margin kiri 4 cm / atas-bawah-kanan 3 cm, heading bab, subbab bold bertingkat, tabel tiga-garis dengan judul di atas dan sumber di bawah, istilah asing miring) ditangani otomatis oleh `scripts/build_bab2.py`. **Tugas Anda menulis isinya dengan benar; skrip yang merapikannya.** Jangan mengetik docx secara manual.

### Hubungan dengan Panduan UNUD (penting)

Panduan UNUD 2024 untuk penelitian empiris menyebut isi BAB II sebagai **Landasan Teoritis** dan **Tinjauan Hasil Penelitian Terkait**. Skill ini memenuhi keduanya lewat **penomoran tematik 2.1–2.7** — pola yang dipakai usulan penelitian Departemen yang sudah diterima (mis. UP_LLU) — bukan lewat dua label literal itu. Subbab 2.1–2.4 dan 2.7 mengisi *landasan teoritis*; subbab 2.5 (perbandingan + tabel sintesis) dan 2.6 (justifikasi) mengisi *tinjauan hasil penelitian terkait*.

**Di luar cakupan skill ini:** Kerangka Berpikir, Kerangka Konsep, dan Hipotesis. Pada panduan UNUD ketiganya berada di **BAB III (Kerangka Berpikir, Konsep, dan Hipotesis Penelitian)**, bukan BAB II. Jangan menambahkannya ke dokumen. Bila user memintanya, sampaikan bahwa itu materi BAB III.

---

## Alur kerja

### Langkah 1 — Pahami penelitiannya (intake)

Skill menulis akurat hanya bila studinya jelas. Kumpulkan dari pesan user, berkas project, atau riwayat percakapan (mis. keluaran `/babpendahuluan` atau BAB I yang sudah ada — sumber terbaik karena daftar referensinya bisa langsung dipakai ulang). Bila ada yang hilang dan menentukan isi bab, tanyakan **sekali** secara ringkas (boleh `ask_user_input_v0`):

- **Judul** (atau topik) penelitian.
- **Desain studi** (RCT, uji diagnostik, kohort, potong-lintang, dll.).
- **PICO:** Populasi, Intervensi, Komparator, Outcome/luaran (termasuk instrumen ukur — mis. SID, SBE, NRS, QoR-15, lactate clearance).
- **Lokasi & konteks lokal** (mis. RS Ngoerah) bila ingin disebut.
- **Referensi yang sudah ada** (BAB I, berkas project) dan **kata kunci** untuk pencarian tambahan.

### Langkah 2 — Riset & verifikasi sitasi

Tinjauan pustaka yang meyakinkan dibangun dari **paper nyata**, bukan klaim umum.

- **Jangan pernah mengarang sitasi.** Setiap `(Penulis, Tahun)` harus merujuk paper yang benar-benar ada.
- **Pakai ulang daftar referensi BAB I** bila tersedia — sumber yang sama menjaga konsistensi antar-bab. Jangkar pada jurnal yang user sediakan di `/mnt/project/` (baca isinya; pakai datanya untuk klaim dan untuk mengisi sel tabel sintesis).
- **Sebagian "PDF" di project bisa berupa arsip berisi halaman hasil pindai (gambar).** Bila perlu menambang angkanya, ekstrak halaman lalu baca dengan kemampuan visual; jangan mengarang isi yang tak terbaca.
- **Lengkapi via connector PubMed dan Consensus** untuk meta-analisis/RCT terbaru yang relevan dengan luaran. Connector perlu di-load lewat `tool_search` lebih dulu (mis. `tool_search(query="pubmed search articles")`, `tool_search(query="consensus search papers")`).
- **Mutakhir & kredibel:** utamakan sumber **≤10 tahun** dari jurnal terakreditasi/internasional. Sumber klasik (mis. deskripsi asli pendekatan Stewart, penemu teknik) boleh lebih lama bila memang rujukan asli.
- **APA 7 dalam-teks:** `Penulis (Tahun)` saat nama jadi subjek, `(Penulis, Tahun)` di akhir kalimat. Dua penulis: `(Andi & Budi, 2023)`. Tiga+: `(Andi et al., 2023)`. Beberapa sumber: `(Andi et al., 2022; Citra & Dewi, 2024)`, diurut lama→baru. Letakkan sitasi **sedekat mungkin** dengan klaimnya.

### Langkah 3 — Tulis isi subbab

Ikuti cetak biru di bawah. Sebelum menulis, baca `references/contoh_anotasi_bab2.md` untuk menyerap **nada, kepadatan, dan ritme** yang sudah diterima penguji. Periksa detail format di `references/format_unud_bab2.md` bila perlu.

### Langkah 4 — Render, validasi, sajikan

Susun isi sebagai satu file JSON, jalankan skrip (lihat **Output**), validasi, lalu `present_files` dokumennya beserta ringkasan singkat.

---

## Cetak biru 7 subbab tematik (2.1–2.7)

Strukturnya mengikuti alur PICO: kenali pasien → pahami fisiologi yang dipertaruhkan → uraikan masing-masing lengan (intervensi lalu komparator) → adu keduanya terhadap luaran (dengan tabel) → nyatakan celah → tutup dengan keamanan. Ini cetak biru **lean**: padat, tidak *over-explained*. Target keseluruhan ±8–11 halaman.

Nomor dan judul subbab bersifat **generik-namun-berjangkar** — instansiasi sesuai topik. Contoh judul di bawah memakai studi Ringerfundin-vs-NaCl pada KAD; ganti sesuai PICO nyata.

**2.1 — Populasi / kondisi klinis. (1 paragraf). DENGAN SITASI.**
Definisikan penyakit/populasi sasaran: patogenesis ringkas, kriteria diagnostik inti, beban epidemiologi, dan garis besar tata laksana yang mengarah ke titik tempat intervensi berperan. Contoh judul: "Ketoasidosis Diabetikum".

**2.2 — Fisiologi & patofisiologi yang dipertaruhkan / dinamai sesuai topik. (≤2 paragraf). DENGAN SITASI.**
Jelaskan mekanisme atau kerangka fisiologis yang menjadi dasar luaran yang diukur. Untuk topik asam-basa: jelaskan pendekatan yang dipakai (mis. Stewart: SID, Atot, pCO₂) lalu bagaimana kondisi pada 2.1 mengganggunya. Beri nama subbab sesuai isi — untuk topik fisikokimia, "anatomi" sering tidak relevan; pakai mis. "Keseimbangan Asam-Basa dan Pendekatan Stewart". Inilah jembatan teoretis yang membuat pilihan intervensi bermakna.

**2.3 — Intervensi (lengan yang diteliti). (2 paragraf). DENGAN SITASI.**
Paragraf 1: prinsip/komposisi/cara kerja intervensi dan dasar teoretis keunggulannya pada mekanisme 2.2. Paragraf 2: bukti empirik yang sudah ada untuk intervensi ini pada populasi terkait (termasuk studi lokal/Indonesia bila ada — sangat dihargai penguji). Contoh judul: "Cairan *Balanced* Ringerfundin".

**2.4 — Komparator (lengan pembanding). (2 paragraf). DENGAN SITASI.**
Paragraf 1: status komparator sebagai baku/lini pertama, komposisi/mekanismenya. Paragraf 2: keterbatasan atau risiko komparator yang memotivasi perbandingan (mis. asidosis hiperkloremik pada salin), dengan angka dari literatur. Akhiri dengan menempatkan komparator sebagai pembanding yang layak diuji. Contoh judul: "Salin 0,9%".

**2.5 — Perbandingan Intervensi vs Komparator terhadap luaran + TABEL sintesis. (2 paragraf mengapit 1 tabel). DENGAN SITASI.**
Inti tinjauan-hasil-penelitian-terkait. Paragraf pembuka: nyatakan bahwa bukti masih bercampur (desain/populasi/luaran berbeda), arahkan ke tabel. **Tabel sintesis** (Tabel 2.1): satu baris per studi utama, kolom mis. Penulis (Tahun) · Desain · Populasi · Perbandingan · Luaran utama · Hasil. Isi sel dari angka nyata yang sudah diverifikasi. Paragraf penutup: tafsirkan pola lintas-studi dan tunjukkan persis bagian yang belum terjawab (mis. sedikit yang memakai dekomposisi Stewart utuh) — menyiapkan 2.6. Gunakan mode `konten` berurutan agar tabel berada **di antara** dua paragraf (lihat skema).

**2.6 — Justifikasi penelitian. (1 paragraf). DENGAN SITASI minimal.**
Rangkum celah secara eksplisit: apa yang belum ada (data pembanding langsung dengan instrumen yang tepat, di lokasi/populasi spesifik, ketiadaan protokol berbasis bukti di institusi), lalu nyatakan apa yang akan dilakukan penelitian ini untuk mengisinya. Ini menggemakan gap di BAB I tetapi dari sudut bukti literatur, dan menjadi jembatan ke BAB III.

**2.7 — Keamanan / pertimbangan klinis. (2 paragraf). DENGAN SITASI.**
Paragraf 1: profil keamanan intervensi (bantah kekhawatiran umum dengan bukti — mis. asetat tidak memicu ketogenesis pada SCOPE-DKA). Paragraf 2: risiko komparator dan pemantauan yang tetap diperlukan terlepas dari lengan (mis. kalium dan glukosa pada resusitasi KAD). Menutup bab dengan nada klinis yang bertanggung jawab.

> **Menyesuaikan jumlah subbab.** Tujuh subbab adalah pola standar untuk studi *dua-lengan*. Bila studi hanya satu intervensi tanpa komparator, gabungkan 2.3–2.4 menjadi satu subbab intervensi + alternatifnya dan sesuaikan 2.5 menjadi "tinjauan bukti terkini" (tabel tetap dipertahankan bila ada cukup studi). Bila luarannya majemuk dan berbeda mekanisme, 2.2 boleh dipecah. Pertahankan alur PICO dan tabel sintesis di subbab perbandingan. Anak-subbab (mis. 2.3.1) hanya bila satu subbab benar-benar perlu dipecah; jangan memaksakan.

---

## Suara akademik — dan cara TIDAK terdengar seperti AI

Penguji konsultan langsung mengenali prosa generik. Tulisan yang diterima itu **padat, spesifik, dan tidak basa-basi**. Patuhi ini:

- **Pasif & impersonal, Bahasa Indonesia baku.** Tanpa "saya/kami/kita/Anda".
- **Istilah asing dicetak miring** dengan menandainya `*seperti ini*` di JSON — skrip merendernya miring, termasuk di dalam sel tabel. Contoh: `*strong ion difference*`, `*base excess*`, `*balanced*`. Akronim baku (ICU, RCT, KAD, SID, SBE) tidak perlu miring.
- **Spesifik, bukan klise.** Sebut angka, nama studi, satuan, ukuran efek (HR, IK 95%, persentase). Hindari frasa kosong: "memegang peranan penting", "tidak dapat dipungkiri", "seiring perkembangan zaman", "di era modern ini", "berbagai macam".
- **Variasikan ritme kalimat.** Selang-seling kalimat kompleks dengan kalimat pendek yang tegas. Hindari pola tiga-serangkai berulang dan kalimat pembuka kosong.
- **Satu klaim yang memajukan argumen per paragraf.** Jangan mengulang gagasan dengan kata berbeda; tiap subbab menggeser pembaca lebih dekat ke gap.
- **Jangan over-explain.** Sepadat contoh di `references/contoh_anotasi_bab2.md`. Konsultan ICU tidak perlu dijelaskan hal dasar.
- **Transisi seperlunya.** "Namun", "Oleh karena itu", "Sebaliknya" hanya saat memang ada pertentangan/sebab-akibat.

**Contoh kalibrasi (buruk → baik):**

> Buruk: "Cairan infus merupakan hal yang sangat penting dan tidak dapat dipungkiri memegang peranan krusial dalam dunia kedokteran modern."
> Baik: "Salin 0,9% mengandung klorida 154 mmol/L sehingga SID-nya bernilai nol, dan pemberian volume besar menurunkan pH sesuai prinsip Stewart (Adrogué et al., 2022)."

---

## Aturan tabel & gambar (kaidah UNUD)

**Tabel** (lihat `references/format_unud_bab2.md` untuk rinci):
- **Judul di ATAS tabel**, rata tengah, format "Tabel 2.1 Judul tabel" — skrip yang menyusun penomoran/penataannya; Anda cukup isi `nomor`, `judul`, `header`, `baris`.
- **Hanya garis horizontal** (tiga-garis: atas header, bawah header, bawah baris terakhir). Tanpa garis vertikal, tanpa garis antar-baris. Skrip menangani ini otomatis.
- **Baris "Sumber:" di bawah tabel** — isi field `sumber`. Untuk tabel sintesis hasil olahan sendiri, tulis "Disusun dari ..." diikuti daftar studi.
- Tabel sebaiknya **muat dalam satu halaman**; sel dirender 10 pt agar ringkas. Ringkas isi sel (frasa, bukan kalimat panjang).

**Gambar:**
- Skrip **tidak menyisipkan gambar berhak-cipta**. Untuk tiap gambar, skrip menulis penanda "[Sisipkan Gambar X di sini]" + **caption di bawah** + baris sumber. User menempelkan gambar berlisensi/milik sendiri secara manual.
- Caption gambar di **bawah**, rata tengah, "Gambar 2.1 Keterangan".
- Hindari mereproduksi figur dari paper; bila perlu skema, anjurkan user membuat ulang/menggambar sendiri.

---

## Catatan hak cipta

Sintesiskan dan kutip seperlunya; **jangan menyalin paragraf utuh** dari paper. Tabel sintesis berisi **ringkasan hasil dalam kata sendiri** + sitasi, bukan kutipan verbatim. Untuk gambar, gunakan penanda placeholder dan minta user menyediakan gambar berlisensi/milik sendiri — skill tidak menyematkan gambar berhak cipta.

---

## Output — render docx dengan skrip bundel

Tulis seluruh isi sebagai satu file JSON (skema persis di `scripts/contoh_input.json`), lalu jalankan skrip dari folder skill yang sedang aktif:

```bash
python <folder-skill>/scripts/build_bab2.py <input.json> /mnt/user-data/outputs/BAB_II_<topik>.docx
```

Skema JSON ringkas:

```json
{
  "judul": "Judul Penelitian (Title Case)",
  "bab_nomor": "II",
  "bab_judul": "TINJAUAN PUSTAKA",
  "subbab": [
    {
      "nomor": "2.1",
      "judul": "Judul Subbab",
      "paragraf": ["paragraf 1", "paragraf 2"]
    },
    {
      "nomor": "2.5",
      "judul": "Subbab dengan tabel di tengah",
      "konten": [
        { "tipe": "paragraf", "teks": "paragraf pengantar ... lihat Tabel 2.1." },
        {
          "tipe": "tabel",
          "nomor": "2.1",
          "judul": "Judul tabel (boleh ada *istilah asing*)",
          "header": ["Penulis (Tahun)", "Desain", "Hasil"],
          "baris": [["Penulis (2024)", "RCT", "ringkasan hasil"]],
          "sumber": "Disusun dari Penulis (2024); ..."
        },
        { "tipe": "paragraf", "teks": "paragraf penutup/penafsiran." }
      ]
    },
    {
      "nomor": "2.x",
      "judul": "Subbab dengan gambar",
      "paragraf": ["..."],
      "gambar": [{ "nomor": "2.1", "caption": "Keterangan gambar", "sumber": "Sumber: ..." }]
    }
  ],
  "referensi": ["Entri APA 7 dengan *nama jurnal* dan *volume* miring.", "..."]
}
```

Konvensi penting saat mengisi JSON:
- Tandai istilah asing dengan `*asterisk*` agar dirender miring — berlaku di paragraf, sel tabel, judul tabel, maupun referensi.
- Tiap subbab memakai **`paragraf`** (daftar string) ATAU **`konten`** (daftar blok berurutan `paragraf`/`tabel`/`gambar`). Pakai `konten` bila tabel/gambar harus berada di antara paragraf (mis. 2.5). Bila pakai kunci sederhana, urutan render adalah paragraf → tabel → gambar.
- Anak-subbab opsional lewat `anak_subbab` (daftar objek bernomor `2.3.1`, dst.) — skrip menata bold sesuai jenjang otomatis dari kedalaman nomor.
- Jangan menaruh nomor manual di awal item daftar; skrip menomori otomatis.
- `nomor` subbab menentukan penataan bold (2.1 = subbab bold; 2.1.1 = anak-subbab bold; 2.1.1.1 = anak-anak tidak bold).

Setelah render, **validasi**: skrip memunculkan peringatan bila subbab hilang/salah nomor, tak ada tabel, atau ada referensi yang tak pernah dikutip. Buka kembali dokumen untuk memastikan subbab 2.1–2.7 lengkap, tabel sintesis ada di subbab perbandingan, dan tiap entri referensi muncul minimal sekali di teks. Lalu `present_files` dokumen + ringkasan 2–3 kalimat (jangan tempel ulang seluruh isi bab). Ingatkan bahwa Kerangka Konsep/Hipotesis adalah materi BAB III.

---

## Berkas pendukung

- `references/contoh_anotasi_bab2.md` — contoh subbab BAB II yang sudah diterima penguji, dianotasi per subbab ke pola PICO + pola sitasi + cara membangun tabel sintesis. **Baca sebelum menulis** untuk menyamakan nada.
- `references/format_unud_bab2.md` — rincian aturan format & bahasa UNUD 2024, dengan penekanan pada aturan tabel tiga-garis dan gambar (acuan bila perlu memeriksa detail).
- `scripts/build_bab2.py` — perender docx (format UNUD otomatis: heading, subbab bertingkat, tabel tiga-garis, sitasi miring).
- `scripts/contoh_input.json` — contoh input JSON lengkap (studi Ringerfundin vs NaCl pada KAD) yang sekaligus jadi demo skema dan kerangka draf.
