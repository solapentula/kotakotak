---
name: babpendahuluan
description: "Menyusun BAB I PENDAHULUAN usulan penelitian (Latar Belakang, Rumusan Masalah, Tujuan, dan Manfaat) sesuai Panduan Penulisan Pascasarjana Universitas Udayana 2024, untuk residen Anestesiologi & Terapi Intensif. WAJIB pakai skill ini setiap kali user mengetik `/babpendahuluan` atau `/babsatu`, ATAU meminta dibuatkan/diperbaiki Latar Belakang, Pendahuluan, BAB 1, atau bab pembuka usulan penelitian/tesis/proposal di bidang anestesi, ICU, perioperatif, hemodinamik, nyeri, sepsis, atau terapi intensif. Juga gunakan ketika user sudah punya judul/PICO yang matang (mis. keluaran dari /usulanpenelitian) dan ingin diteruskan ke penulisan BAB I dalam format docx. Output utamanya adalah file .docx siap-pakai sesuai kaidah UNUD, bukan jawaban di chat."
license: Proprietary
---

# Penyusun BAB I PENDAHULUAN — Usulan Penelitian UNUD 2024

## Apa yang dihasilkan skill ini

Sebuah file **.docx** berisi BAB I PENDAHULUAN yang lolos pembacaan penguji (Spesialis Anestesiologi & Terapi Intensif Konsultan), terdiri atas empat subbab:

- **1.1 Latar Belakang** — 8 paragraf dengan arsitektur **MDAEK**
- **1.2 Rumusan Masalah** — pertanyaan penelitian
- **1.3 Tujuan Penelitian** — 1.3.1 Tujuan umum & 1.3.2 Tujuan khusus
- **1.4 Manfaat Penelitian** — 1.4.1 Manfaat teoritis & 1.4.2 Manfaat praktis

Ditambah **Daftar Referensi BAB I** (APA 7) di akhir dokumen sebagai alat bantu, dan **bukan** bagian formal bab.

Formatting (A4, Times New Roman 12, spasi 1,5, margin kiri 4 cm / atas-bawah-kanan 3 cm, heading bab, istilah asing miring) ditangani secara otomatis oleh `scripts/build_bab1.py`. **Tugas Anda adalah menulis isinya dengan benar; skrip yang merapikannya.** Jangan mengetik docx secara manual.

---

## Alur kerja

### Langkah 1 — Pahami penelitiannya (intake)

Skill ini menulis dengan akurat hanya jika studinya jelas. Kumpulkan dari pesan user, berkas project, atau riwayat percakapan (mis. keluaran `/usulanpenelitian`). Jika ada yang hilang dan menentukan isi bab, tanyakan **sekali** secara ringkas (boleh pakai `ask_user_input_v0`):

- **Judul** (atau topik) penelitian.
- **Desain studi** (mis. RCT double-blind, uji diagnostik, kohort, potong-lintang, dll.).
- **PICO / fokus:** Populasi, Intervensi/paparan, Komparator, Outcome/luaran utama (termasuk instrumen ukur, mis. NRS, QoR-15, lactate clearance).
- **Lokasi & konteks lokal** (mis. RS Ngoerah / sentra tertentu) bila ingin disebut.
- **Jurnal/referensi yang sudah disediakan** di berkas project, dan **kata kunci** untuk pencarian tambahan.

**Pertimbangan blinding (di luar teks bab).** Jika studi bersifat intervensi/RCT, nilai sebentar kelayakan penyamaran memakai kerangka 5 kelompok di `references/blinding_check.md` (pasien, klinisi/operator, pengumpul data, penilai luaran, analis). Sampaikan kesimpulannya **dalam chat sebagai catatan singkat** ("studi ini layak double-blind dengan menyamarkan ... ; operator tidak dapat dibutakan") supaya membantu user memutuskan desain — **jangan** memasukkan pembahasan blinding ke dalam BAB I.

### Langkah 2 — Riset & verifikasi sitasi

Latar Belakang yang meyakinkan dibangun dari **fakta empirik nyata**, bukan klaim umum. Karena itu:

- **Jangan pernah mengarang sitasi.** Setiap `(Penulis, Tahun)` harus merujuk paper yang benar-benar ada — entah dari berkas project atau dari hasil pencarian.
- **Jangkar pada jurnal yang user sediakan** di `/mnt/project/` (baca isinya, pakai datanya untuk klaim utama).
- **Lengkapi via connector PubMed dan Consensus** untuk: angka epidemiologi/prevalensi (paragraf 2), data dampak/komplikasi (paragraf 3), dan studi terdekat yang menegaskan gap (paragraf 7). Connector ini perlu di-load lewat `tool_search` lebih dulu (mis. `tool_search(query="pubmed search articles")`).
- **Mutakhir & kredibel:** utamakan sumber **≤10 tahun** dari jurnal terakreditasi/internasional (Pedoman UNUD hlm. 23). Sumber klasik/penemu teknik (mis. deskripsi pertama suatu blok) boleh lebih lama bila memang rujukan asli.
- **Format dalam-teks APA 7 (identik dengan Harvard untuk in-text):** `Penulis (Tahun)` saat nama jadi subjek kalimat, atau `(Penulis, Tahun)` di akhir kalimat. Dua penulis: `(Andi & Budi, 2023)`. Tiga+ penulis: `(Andi et al., 2023)`. Beberapa sumber: `(Andi et al., 2022; Citra & Dewi, 2024)`, diurut dari lama ke baru. Letakkan sitasi **sedekat mungkin** dengan klaim yang didukung, bukan menumpuk di akhir paragraf.

### Langkah 3 — Tulis isi keempat subbab

Ikuti cetak biru di bawah. Sebelum menulis, baca `references/contoh_anotasi.md` untuk menyerap **nada, kepadatan, dan ritme** contoh yang sudah diterima penguji.

### Langkah 4 — Render docx

Susun isi sebagai satu file JSON lalu jalankan skrip (lihat bagian **Output**). Validasi, lalu `present_files` dokumennya beserta ringkasan singkat.

---

## Cetak biru 1.1 Latar Belakang — arsitektur MDAEK (8 paragraf)

Latar Belakang bergerak seperti corong: dari gambaran luas, mengerucut ke satu celah pengetahuan spesifik, lalu ke tujuan. Pedoman UNUD mengharuskan terlihat **kesenjangan antara yang ideal (*das sollen*) dan kenyataan (*das sein*)** yang ditopang fakta empirik (hlm. 10). Delapan paragraf membagi beban itu:

**Paragraf 1 — Pembuka panoramik. TANPA SITASI.**
Ini "suara peneliti": evolusi/konteks bidang → munculkan masalah klinis inti → singgung dampaknya → arahkan ke kelas solusi → tutup dengan celah/pertanyaan yang memotivasi studi. Ini versi mini seluruh bab (M-D-A-E-K dalam 5–7 kalimat). Tidak ada angka atau sitasi di sini karena fungsinya membingkai, bukan membuktikan.

**Paragraf 2 — Masalah & epidemiologi. DENGAN SITASI. ±4 kalimat.**
Tetapkan besaran masalah dengan angka dari literatur (prevalensi/insidensi/adopsi), gambarkan praktik/konteks lokal bila relevan, dan ringkas mekanisme masalahnya. Inilah paragraf paling padat sitasi.

**Paragraf 3 — Dampak. DENGAN SITASI.**
Konsekuensi klinis bila masalah tak ditangani: komplikasi, luaran jangka panjang, beban pada pasien/sistem. Pakai angka spesifik (mis. insidensi komplikasi tertentu), jangan generalisasi.

**Paragraf 4 — Area / lanskap solusi. DENGAN SITASI.**
Petakan pendekatan yang tersedia untuk mengatasi masalah, lalu posisikan kelas intervensi yang Anda teliti di dalam lanskap itu (mis. tempatnya dalam guideline/protokol). Tunjukkan mengapa kelas ini layak dikejar.

**Paragraf 5 — Opsi/komparator pertama. DENGAN SITASI.**
Uraikan teknik/intervensi pertama: prinsip kerja, kekuatan, dan keterbatasan yang relevan dengan pertanyaan penelitian.

**Paragraf 6 — Opsi/intervensi kedua. DENGAN SITASI.**
Uraikan teknik/intervensi kedua (yang Anda usung) dibanding yang pertama: perbedaan mendasar, potensi keunggulan, dan trade-off/risikonya. Akhir paragraf 5–6 sudah harus terasa menuju "keduanya belum pernah diadu langsung".

**Paragraf 7 — Kesenjangan (gap). DENGAN SITASI.**
Nyatakan secara eksplisit apa yang **belum** diketahui/dibandingkan. Sebutkan studi terdekat yang ada dan mengapa belum menjawab (populasi berbeda, luaran berbeda, dsb.). Sertakan celah lokal bila ada (mis. belum ada SOP berbasis bukti di institusi). Inilah justifikasi utama penelitian.

**Paragraf 8 — Tujuan & relevansi. Sitasi minimal/boleh tanpa.**
Tegaskan apa yang akan dilakukan penelitian ini untuk mengisi gap, di lokasi/populasi spesifik, dan manfaat nyatanya. Paragraf ini menjadi jembatan ke 1.2 Rumusan Masalah.

> Catatan jumlah: target **tepat 8 paragraf**. Bila topik sederhana dan hanya ada satu intervensi (bukan perbandingan dua teknik), gabungkan beban paragraf 5–6 menjadi pembahasan mendalam satu intervensi + alternatifnya, tetap menjaga 8 paragraf dan alur corong yang sama.

---

## Suara akademik — dan cara TIDAK terdengar seperti AI

Penguji konsultan langsung mengenali prosa generik. Tulisan yang diterima itu **padat, spesifik, dan tidak basa-basi**. Patuhi ini:

- **Pasif & impersonal, Bahasa Indonesia baku.** Tanpa "saya/kami/kita/Anda". (Pedoman hlm. 23.)
- **Istilah asing dicetak miring** dengan menandainya `*seperti ini*` di teks JSON — skrip akan merendernya miring. Contoh: `*erector spinae plane*`, `*time to first rescue analgesia*`. Akronim yang sudah baku (VATS, ICU, RCT) tidak perlu miring.
- **Spesifik, bukan klise.** Sebut angka, nama teknik, nama instrumen, satuan. Hindari frasa kosong: "memegang peranan penting", "tidak dapat dipungkiri", "seiring perkembangan zaman", "di era modern ini", "berbagai macam", "sangat krusial" (pakai sangat hemat).
- **Variasikan ritme kalimat.** Selang-seling kalimat kompleks dengan kalimat pendek yang tegas. Hindari pola tiga-serangkai yang berulang dan kalimat pembuka kosong ("Penanganan X merupakan hal yang penting.").
- **Satu klaim per paragraf yang memajukan argumen.** Jangan mengulang gagasan yang sama dengan kata berbeda; setiap paragraf harus menggeser pembaca lebih dekat ke gap.
- **Jangan over-explain.** Sepadat contoh di `references/contoh_anotasi.md`. Cukupkan; jangan menjelaskan hal yang sudah jelas bagi konsultan ICU.
- **Transisi seperlunya.** "Namun", "Oleh karena itu", "Sebaliknya" dipakai bila memang ada pertentangan/sebab-akibat — bukan sebagai pengisi di tiap awal paragraf.

**Contoh kalibrasi (buruk → baik):**

> Buruk: "Nyeri pascaoperasi merupakan masalah yang sangat penting dan tidak dapat dipungkiri memegang peranan krusial dalam dunia kedokteran modern."
> Baik: "Nyeri derajat sedang–berat masih dijumpai pada 24 jam pertama pascaoperasi meski prosedur bersifat minimal invasif (Batchelor et al., 2019)."

---

## 1.2 Rumusan Masalah

Satu kalimat pengantar ("Berdasarkan latar belakang di atas, rumusan masalah penelitian ini adalah:"), diikuti **pertanyaan penelitian bernomor** (1., 2., 3., …) — gunakan penomoran, **bukan** tanda hubung atau bullet (Pedoman melarang bullet/dash untuk perincian, hlm. 21). Setiap pertanyaan harus selaras dengan luaran yang nanti dibahas, dalam bentuk kalimat tanya ("Apakah terdapat perbedaan ...?"). Jumlah pertanyaan = jumlah luaran utama.

## 1.3 Tujuan Penelitian

- **1.3.1 Tujuan umum** — satu kalimat/paragraf tujuan menyeluruh, sejajar dengan judul.
- **1.3.2 Tujuan khusus** — daftar bernomor; jumlah dan isinya **bercermin** pada Rumusan Masalah (mengubah "Apakah terdapat perbedaan ...?" menjadi "Membuktikan/Menganalisis perbedaan ..."). Gunakan kata kerja yang sesuai jenjang (residen spesialis → "membuktikan", "menganalisis", "mengevaluasi").

## 1.4 Manfaat Penelitian

- **1.4.1 Manfaat teoritis** — kontribusi bagi pengembangan ilmu (mengisi data perbandingan yang langka, dasar penelitian lanjutan). Daftar bernomor.
- **1.4.2 Manfaat praktis** — manfaat bagi keputusan klinis, pasien, dan institusi (mis. dasar penyusunan SOP berbasis bukti). Daftar bernomor.

## Daftar Referensi BAB I (alat bantu)

Di akhir dokumen, tampilkan semua sumber yang dikutip di BAB I dalam **APA 7**, terurut alfabetis, dengan nama jurnal & volume ditandai `*miring*`. Beri judul "Daftar Referensi (BAB I)" dan satu baris keterangan bahwa ini daftar kerja untuk memudahkan kompilasi Daftar Pustaka akhir. **Hanya cantumkan sumber yang benar-benar dikutip dan benar-benar ada.**

---

## Output — render docx dengan skrip bundel

Tulis seluruh isi sebagai satu file JSON (skema persis di `scripts/contoh_input.json`), lalu jalankan skrip dari dalam folder skill ini (gunakan path skrip sesuai lokasi skill yang sedang aktif):

```bash
python <folder-skill>/scripts/build_bab1.py <input.json> /mnt/user-data/outputs/BAB_I_<topik>.docx
```

Skema JSON ringkas:

```json
{
  "judul": "JUDUL DALAM HURUF KAPITAL",
  "latar_belakang": ["paragraf 1 (tanpa sitasi)", "...", "paragraf 8"],
  "rumusan_pengantar": "Berdasarkan latar belakang di atas, rumusan masalah penelitian ini adalah:",
  "rumusan_masalah": ["pertanyaan 1?", "pertanyaan 2?"],
  "tujuan_umum": "kalimat tujuan umum",
  "tujuan_khusus": ["tujuan khusus 1", "tujuan khusus 2"],
  "manfaat_teoritis": ["manfaat teoritis 1", "..."],
  "manfaat_praktis": ["manfaat praktis 1", "..."],
  "referensi": ["Entri APA 7 dengan *nama jurnal* miring.", "..."]
}
```

Konvensi penting saat mengisi JSON:
- Tandai istilah asing dengan `*asterisk*` agar dirender miring (berlaku di paragraf, daftar, maupun referensi).
- `latar_belakang` harus berisi **8** string (satu per paragraf). Paragraf 1 tidak boleh mengandung pola sitasi `(... , tahun)`.
- Jangan menaruh nomor manual di awal item daftar (skrip menomori otomatis).

Setelah render, **validasi** isinya: buka kembali untuk memastikan 8 paragraf, sitasi tidak ada di paragraf 1, dan setiap entri referensi muncul minimal sekali di teks. Lalu `present_files` dokumen + sampaikan ringkasan 2–3 kalimat (jangan tempel ulang seluruh isi bab).

---

## Berkas pendukung

- `references/contoh_anotasi.md` — contoh Latar Belakang yang sudah diterima penguji, dianotasi per paragraf ke pola MDAEK + pola sitasi. **Baca sebelum menulis** untuk menyamakan nada.
- `references/format_unud.md` — rincian aturan format & bahasa UNUD 2024 (acuan bila perlu memeriksa detail).
- `references/blinding_check.md` — kerangka kelayakan blinding 5 kelompok (hanya untuk catatan pertimbangan di chat; tidak masuk BAB I).
- `scripts/build_bab1.py` — perender docx (format UNUD otomatis).
- `scripts/contoh_input.json` — contoh input JSON lengkap.
