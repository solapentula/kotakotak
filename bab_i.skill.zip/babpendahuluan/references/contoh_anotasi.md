# Contoh Latar Belakang yang diterima penguji — anotasi MDAEK

Ini Latar Belakang dari usulan penelitian yang sudah lolos pembacaan penguji (perbandingan blok MTP vs ESP pada VATS). Pakai sebagai **kalibrasi nada, kepadatan, dan pola sitasi** — bukan untuk disalin. Perhatikan: kalimat padat, angka spesifik, sitasi dekat klaim, istilah asing miring, pasif, dan setiap paragraf menggeser argumen menuju gap.

---

**Paragraf 1 — Pembuka panoramik (TANPA SITASI).**
> Perkembangan ilmu bedah toraks telah berevolusi dari *open thoracotomy* menuju *video-assisted thoracoscopic surgery* (VATS), sebuah pendekatan bedah yang bersifat minimal invasif. Meski menawarkan pemulihan lebih cepat, manajemen nyeri pascaoperasi tetap menjadi tantangan klinis yang signifikan. Kontrol nyeri yang adekuat sangat krusial untuk memastikan ventilasi optimal dan mobilisasi dini. Dalam konteks ini, blok bidang fasia berbasis ultrasonografi (USG) muncul sebagai solusi menjanjikan. Namun, blok *erector spinae plane* (ESP) dan blok *midpoint transverse process to pleura* (MTP) belum pernah dibandingkan secara langsung pada VATS, sehingga penelitian komparatif keduanya menjadi sangat diperlukan.

*Anotasi:* M (tantangan nyeri) → D (ventilasi/mobilisasi) → A (blok bidang fasia USG) → E (ESP & MTP) → K (belum diadu langsung → perlu studi). Nol sitasi, nol angka. Inilah "suara peneliti".

**Paragraf 2 — Masalah & epidemiologi (SITASI, ±4 kalimat).**
> VATS kini menjadi prosedur yang telah diadopsi lebih dari 80% pada pasien yang menjalani reseksi paru terkait keganasan (Lei et al., 2025). Nyeri pascaoperasi derajat sedang hingga berat masih sering dijumpai dalam 24 jam pertama walaupun operasi ini termasuk tindakan yang bersifat minimal invasif (Batchelor et al., 2019). Selama ini, manajemen nyeri pasca VATS di RS Ngoerah masih belum baku ... Mekanisme nyerinya bersifat multifaktorial, mulai dari trauma tempat insersi *port*, cedera saraf interkostal, hingga iritasi pleura (Batchelor et al., 2019).

*Anotasi:* angka adopsi (80%) + besaran masalah + konteks lokal + mekanisme ringkas. Padat sitasi.

**Paragraf 3 — Dampak (SITASI).**
> Nyeri yang tidak tertangani dapat memicu *splinting* yang berujung pada atelektasis hingga gagal napas (Batchelor et al., 2019). Selain itu, nyeri akut merupakan prediktor terkuat *chronic post surgical pain* (CPSP), yang pada pasien VATS uniportal mencapai insidensi 29,7% di bulan ketiga (S. Wang et al., 2020). ...

*Anotasi:* konsekuensi konkret + angka insidensi spesifik (29,7%). Bukan generalisasi.

**Paragraf 4 — Area/lanskap solusi (SITASI).**
> Pendekatan multimodal termasuk dalam manajemen nyeri pasca VATS. Meski TEA sempat menjadi standar emas, risiko hipotensi dan kontraindikasi lain mendorong pencarian teknik alternatif (Liang et al., 2021). ... blok bidang fasia yang lebih superfisial kini direkomendasikan sebagai komponen integral dalam protokol *Enhanced Recovery After Surgery* (ERAS) (Batchelor et al., 2019; Feray et al., 2022).

*Anotasi:* memetakan lanskap (TEA → PVB → blok fasia) dan menautkan kelas intervensi ke guideline.

**Paragraf 5 — Komparator pertama (SITASI).**
> Blok ESP diperkenalkan oleh Forero et al. (2016) melalui injeksi anestetik lokal pada bidang fasia antara otot *erector spinae* dan *processus transversus*. ... Meski aman dan mudah dipelajari, penyebaran anestetik pada blok ESP cenderung bervariasi, sehingga konsistensi efeknya antar pasien sulit diprediksi (Das Adhikary et al., 2018; Taketa et al., 2020).

*Anotasi:* prinsip + kekuatan + keterbatasan relevan (variabilitas). Sitasi penemu pakai narasi `Forero et al. (2016)`.

**Paragraf 6 — Intervensi kedua vs pertama (SITASI).**
> Sebagai penyempurnaan PVB, blok MTP menempatkan ujung jarum pada titik tengah antara *processus transversus* dan pleura (Costache et al., 2017). ... Dibandingkan ESP, blok MTP secara anatomis lebih dekat ke ruang paravertebral, sehingga memiliki konsekuensi risiko pneumotoraks yang lebih tinggi (Swathi et al., 2021).

*Anotasi:* perbedaan mendasar + potensi keunggulan + trade-off (risiko). Sudah terasa menuju "perlu diadu".

**Paragraf 7 — Kesenjangan/gap (SITASI).**
> Saat ini, perbandingan langsung antara blok ESP dan MTP pada populasi VATS masih sangat terbatas karena studi umumnya hanya membandingkan masing-masing teknik terhadap PVB atau TEA (de Souza Makiyama Lopes et al., 2025; Durey et al., 2023; Swathi et al., 2021). Belum ada studi yang mengevaluasi perbedaan kualitas pemulihan menggunakan *Quality of Recovery-15* (QoR-15) antara kedua teknik ... RS Ngoerah ... belum memiliki protokol analgesia regional berbasis bukti ...

*Anotasi:* gap global (belum head-to-head) + gap instrumen (QoR-15) + gap lokal (SOP). Inilah justifikasi inti.

**Paragraf 8 — Tujuan & relevansi (sitasi minimal).**
> RS Ngoerah merupakan rumah sakit rujukan nasional dengan volume kasus VATS yang signifikan. Penelitian ini diharapkan menjadi landasan pengembangan SOP analgesia regional di RS Ngoerah, sekaligus memberikan manfaat nyata bagi pasien VATS di wilayah Bali dan Indonesia Timur.

*Anotasi:* relevansi lokal + apa yang akan diisi + manfaat nyata. Jembatan ke Rumusan Masalah.

---

## Pola yang harus ditiru (ringkas)
- Angka selalu spesifik dan bersitasi (80%, 29,7%), tidak "banyak/tinggi" tanpa data.
- Sitasi melekat pada kalimat klaimnya, bukan menumpuk di akhir paragraf.
- Istilah asing miring; akronim baku (VATS, ESP, MTP, ERAS) tidak.
- Tiap paragraf satu fungsi; tidak ada pengulangan gagasan.
- Penutup tiap paragraf 5–7 sudah mengarahkan ke ketiadaan perbandingan langsung.
